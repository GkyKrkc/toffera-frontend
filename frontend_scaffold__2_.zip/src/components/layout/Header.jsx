import { useState, useRef, useEffect } from "react"
import { useNavigate, Link } from "react-router-dom"
import {
  Search, PlusCircle, MessageSquare, Bell, Menu, X, Circle,
  LayoutDashboard, LogOut, User, ChevronDown, Settings,
  Building2, Car, Layers, Shield,
} from "lucide-react"
import { useAuth } from "@/store/AuthContext"

// TODO: bildirim sistemi kurulduğunda (Echo/WebSocket + gerçek
// DatabaseNotification akışı) bu mock veriler kaldırılıp useNotifications
// benzeri bir hook ile değiştirilecek.
const MOCK_MESSAGES = [
  { id: 1, sender: "Ahmet Yılmaz", subject: "Passat İlanı", snippet: "Son fiyat ne olur? Ciddi alıcıyım.", time: "5 dk önce", unread: true },
  { id: 2, sender: "Mehmet Demir", subject: "iPhone 15 Pro Max", snippet: "Takas düşünüyor musunuz?", time: "45 dk önce", unread: true },
  { id: 3, sender: "Ayşe Kaya", subject: "Kiralık Daire", snippet: "Evi akşam görebilir miyiz?", time: "2 saat önce", unread: true },
  { id: 4, sender: "Caner Tekin", subject: "Yamaha XMAX", snippet: "Motorun hasar kaydı var mı?", time: "Dün", unread: true },
  { id: 5, sender: "Ahmet Otomotiv", subject: "Egea İlanı", snippet: "Aracınız için ekspertiz randevusu...", time: "Dün", unread: true },
]

const MOCK_NOTIFICATIONS = [
  { id: 1, text: 'Favoriye aldığınız "Kadıköy Kiralık Daire" ilanının fiyatı düştü!', type: "price_drop", time: "10 dk önce", unread: true },
  { id: 2, text: "Yeni bir cihazdan hesabınıza giriş yapıldı.", type: "security", time: "1 saat önce", unread: true },
  { id: 3, text: "Arama kaydınıza uygun 5 yeni ilan eklendi.", type: "saved_search", time: "3 saat önce", unread: true },
]

/**
 * Paylaşılan site header'ı — SMS/Şifre login öncesi ve sonrası tüm sayfalarda
 * (HomePage, AccountPage, ileride MarketPage vb.) kullanılacak.
 *
 * Props:
 * - showCategoryMenuToggle: sol üstte kategori sidebar'ını açıp kapatan
 *   hamburger butonunu gösterir. Sadece bu sidebar'a sahip sayfalarda
 *   (şu an: HomePage) true geçilmeli.
 * - isMobileMenuOpen / onMobileMenuToggle: yukarıdaki hamburger'ın state'i,
 *   sidebar'a sahip olan sayfa tarafından kontrol edilir.
 * - onLogoClick: logoya tıklanınca ekstra bir davranış gerekiyorsa
 *   (örn. HomePage'de açık olan ilan modalını kapatmak) buradan verilir.
 */
export default function Header({
                                 showCategoryMenuToggle = false,
                                 isMobileMenuOpen = false,
                                 onMobileMenuToggle = () => {},
                                 onLogoClick,
                               }) {
  const navigate = useNavigate()
  const { user, isAuthenticated, isAgent, isAdmin, logout } = useAuth()

  const [isMessagesOpen, setIsMessagesOpen] = useState(false)
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false)
  const [isAccountOpen, setIsAccountOpen] = useState(false)

  const dropdownRef = useRef(null)
  const accountRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsMessagesOpen(false)
        setIsNotificationsOpen(false)
      }
      if (accountRef.current && !accountRef.current.contains(event.target)) {
        setIsAccountOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const avatarInitials = user?.name
      ?.split(" ")
      .map(n => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase()

  // Rol etiketi — RegisterPage'deki ACCOUNT_TYPES (buyer/emlakci/galerici/her_ikisi)
  // ile birebir aynı mantık; backend user objesinde agent_type ya da
  // account_type olarak dönebiliyor, ikisini de destekliyoruz.
  const getRoleInfo = () => {
    if (isAdmin) return { label: "Yönetici", icon: Shield }
    if (isAgent) {
      const t = user?.agent_type || user?.account_type
      if (t === "emlakci")   return { label: "Emlak Uzmanı",   icon: Building2 }
      if (t === "galerici")  return { label: "Vasıta Uzmanı",  icon: Car }
      if (t === "her_ikisi") return { label: "Emlak & Vasıta", icon: Layers }
    }
    return { label: "Müşteri", icon: User }
  }
  const roleInfo = getRoleInfo()

  const handleLogout = async () => {
    await logout()
    setIsAccountOpen(false)
    navigate("/")
  }

  const handleLogoClick = (e) => {
    if (onLogoClick) {
      e.preventDefault()
      onLogoClick()
    }
  }

  return (
      <header className="bg-gradient-to-r from-indigo-800 via-purple-700 to-fuchsia-600 border-b border-purple-900 sticky top-0 z-50 shadow-md">
        {/* Logo titreme animasyonu — sadece burada kullanılıyor */}
        <style>{`
        @keyframes logoPulseShake {
          0% { transform: scale(1) rotate(0deg); opacity: 1; }
          5% { transform: scale(1.03) rotate(-2deg); opacity: 0.9; }
          10% { transform: scale(1.03) rotate(2deg); opacity: 0.9; }
          15% { transform: scale(1.03) rotate(-2deg); opacity: 0.9; }
          20% { transform: scale(1) rotate(0deg); opacity: 1; }
          100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        .logo-anim {
          display: inline-block;
          animation: logoPulseShake 3s infinite ease-in-out;
        }
      `}</style>

        <div className="max-w-[1200px] mx-auto px-4">
          <div className="flex items-center justify-between h-16">

            {/* Logo & Mobil Menü */}
            <div className="flex items-center gap-4">
              {showCategoryMenuToggle && (
                  <button
                      className="md:hidden p-1 text-white hover:bg-white/20 rounded transition-colors"
                      onClick={onMobileMenuToggle}
                  >
                    {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                  </button>
              )}
              <Link to="/" onClick={handleLogoClick} className="flex flex-col items-start leading-none cursor-pointer">
                <span className="text-2xl font-extrabold tracking-tight text-white logo-anim">TeklifMeydanı.</span>
                <span className="text-[10px] font-medium text-purple-200 tracking-widest uppercase">Güvenli Alışveriş</span>
              </Link>
            </div>

            {/* Arama Çubuğu (Masaüstü) */}
            <div className="hidden md:flex flex-1 max-w-2xl mx-8 relative group">
              <input
                  type="text"
                  placeholder="Kelime, ilan no veya mağaza adı ile ara"
                  className="w-full pl-4 pr-12 py-2.5 rounded shadow-inner outline-none text-sm border border-transparent focus:border-purple-400 focus:ring-2 focus:ring-purple-400 transition-all bg-white"
              />
              <button className="absolute right-0 top-0 h-full px-3 text-gray-500 hover:text-purple-600 bg-gray-100 border-l rounded-r flex items-center justify-center transition-colors">
                <Search size={18} />
              </button>
            </div>

            {/* Kullanıcı Menüsü ve Butonlar */}
            <div className="flex items-center gap-4">
              {!isAuthenticated && (
                  <div className="hidden lg:flex items-center gap-4 text-sm font-medium text-white">
                    <Link to="/login" className="hover:text-purple-200 transition-colors">Giriş Yap</Link>
                    <span className="text-purple-400">|</span>
                    <Link to="/register" className="hover:text-purple-200 transition-colors">Üye Ol</Link>
                  </div>
              )}

              {isAuthenticated && (
                  <div className="flex items-center gap-3 text-white" ref={dropdownRef}>

                    {/* Mesajlar */}
                    <div className="relative">
                      <button
                          onClick={() => { setIsMessagesOpen(!isMessagesOpen); setIsNotificationsOpen(false) }}
                          className={`p-1.5 rounded-full transition-colors relative ${isMessagesOpen ? "bg-white/20" : "hover:bg-white/20"}`}
                      >
                        <MessageSquare size={20} />
                        <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full border border-purple-800 shadow-sm">
                      5
                    </span>
                      </button>

                      {isMessagesOpen && (
                          <div className="absolute top-12 right-0 w-80 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-[60] animate-in slide-in-from-top-2 duration-200">
                            <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex justify-between items-center">
                              <span className="font-bold text-gray-800 text-sm">Mesajlar (5 Yeni)</span>
                              <a href="#" className="text-xs text-purple-600 hover:underline">Tümünü Okundu İşaretle</a>
                            </div>
                            <div className="max-h-[350px] overflow-y-auto">
                              {MOCK_MESSAGES.map(msg => (
                                  <div key={msg.id} className="p-4 border-b border-gray-50 hover:bg-purple-50 transition-colors cursor-pointer flex gap-3">
                                    <div className="w-10 h-10 rounded-full bg-indigo-100 flex-shrink-0 flex items-center justify-center text-indigo-700 font-bold uppercase">
                                      {msg.sender.charAt(0)}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <div className="flex justify-between items-start mb-0.5">
                                        <h4 className="font-bold text-gray-800 text-sm truncate pr-2">{msg.sender}</h4>
                                        <span className="text-[10px] text-gray-400 whitespace-nowrap">{msg.time}</span>
                                      </div>
                                      <p className="text-xs text-indigo-600 font-medium truncate">{msg.subject}</p>
                                      <p className="text-xs text-gray-500 truncate mt-0.5">{msg.snippet}</p>
                                    </div>
                                    {msg.unread && <Circle size={8} className="fill-purple-600 text-purple-600 mt-2" />}
                                  </div>
                              ))}
                            </div>
                            <div className="p-3 text-center bg-gray-50 border-t border-gray-100 hover:bg-gray-100 transition-colors cursor-pointer">
                              <span className="text-sm font-semibold text-purple-700">Tüm Mesajları Gör</span>
                            </div>
                          </div>
                      )}
                    </div>

                    {/* Bildirimler */}
                    <div className="relative">
                      <button
                          onClick={() => { setIsNotificationsOpen(!isNotificationsOpen); setIsMessagesOpen(false) }}
                          className={`p-1.5 rounded-full transition-colors relative ${isNotificationsOpen ? "bg-white/20" : "hover:bg-white/20"}`}
                      >
                        <span className="absolute inset-1.5 rounded-full bg-purple-300 opacity-75 animate-ping z-0"></span>
                        <Bell size={20} className="relative z-10" />
                        <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full border border-purple-800 shadow-sm z-20">
                      3
                    </span>
                      </button>

                      {isNotificationsOpen && (
                          <div className="absolute top-12 -right-10 sm:right-0 w-80 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-[60] animate-in slide-in-from-top-2 duration-200">
                            <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex justify-between items-center">
                              <span className="font-bold text-gray-800 text-sm">Bildirimler (3 Yeni)</span>
                              <a href="#" className="text-xs text-purple-600 hover:underline">Ayarlar</a>
                            </div>
                            <div className="max-h-[350px] overflow-y-auto">
                              {MOCK_NOTIFICATIONS.map(notif => (
                                  <div key={notif.id} className="p-4 border-b border-gray-50 hover:bg-purple-50 transition-colors cursor-pointer flex gap-3">
                                    <div className="flex-1">
                                      <p className="text-sm text-gray-700 leading-snug">{notif.text}</p>
                                      <span className="text-[11px] text-gray-400 mt-1 block">{notif.time}</span>
                                    </div>
                                    {notif.unread && <Circle size={8} className="fill-purple-600 text-purple-600 mt-1 flex-shrink-0" />}
                                  </div>
                              ))}
                            </div>
                            <div className="p-3 text-center bg-gray-50 border-t border-gray-100 hover:bg-gray-100 transition-colors cursor-pointer">
                              <span className="text-sm font-semibold text-purple-700">Tüm Bildirimleri Gör</span>
                            </div>
                          </div>
                      )}
                    </div>

                    {/* Hesap Avatarı & Dropdown */}
                    <div className="relative ml-1" ref={accountRef}>
                      <button
                          onClick={() => setIsAccountOpen(!isAccountOpen)}
                          className={`flex items-center gap-2 border border-white/20 py-1.5 px-3 rounded-full transition-all ${isAccountOpen ? "bg-white/20" : "bg-white/10 hover:bg-white/20"}`}
                      >
                        <div className="w-6 h-6 rounded-full bg-white text-purple-700 flex items-center justify-center font-bold text-[11px] uppercase shadow-sm">
                          {avatarInitials || <User size={13} />}
                        </div>
                        <span className="text-sm font-semibold hidden md:block whitespace-nowrap">
                      {avatarInitials} - {roleInfo.label}
                    </span>
                        <ChevronDown size={14} className={`hidden sm:block transition-transform duration-200 ${isAccountOpen ? "rotate-180" : ""}`} />
                      </button>

                      {isAccountOpen && (
                          <div className="absolute top-12 right-0 w-56 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-[60] animate-in slide-in-from-top-2 duration-200 text-gray-800">
                            <div className="p-4 border-b border-gray-100 bg-gray-50">
                              <p className="font-bold text-sm truncate">{user?.name}</p>
                              <p className="text-xs text-gray-500 mt-0.5 truncate">{user?.email || user?.phone}</p>
                              <div className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 border border-purple-100 px-2 py-1 rounded-md mt-2">
                                <roleInfo.icon size={11} /> {roleInfo.label}
                              </div>
                            </div>
                            <div className="py-2">
                              <Link
                                  to="/dashboard"
                                  onClick={() => setIsAccountOpen(false)}
                                  className="w-full text-left px-4 py-2.5 text-sm hover:bg-purple-50 hover:text-purple-700 transition-colors flex items-center gap-3"
                              >
                                <LayoutDashboard size={16} className="text-gray-400" /> Panelim
                              </Link>
                              <Link
                                  to="/account"
                                  onClick={() => setIsAccountOpen(false)}
                                  className="w-full text-left px-4 py-2.5 text-sm hover:bg-purple-50 hover:text-purple-700 transition-colors flex items-center gap-3"
                              >
                                <User size={16} className="text-gray-400" /> Profilim
                              </Link>
                              <Link
                                  to="/settings"
                                  onClick={() => setIsAccountOpen(false)}
                                  className="w-full text-left px-4 py-2.5 text-sm hover:bg-purple-50 hover:text-purple-700 transition-colors flex items-center gap-3"
                              >
                                <Settings size={16} className="text-gray-400" /> Ayarlar
                              </Link>
                            </div>
                            <div className="border-t border-gray-100 py-1.5 px-1.5">
                              <button
                                  onClick={handleLogout}
                                  className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-semibold text-red-600 hover:bg-red-50 transition-colors"
                              >
                                <LogOut size={15} /> Çıkış Yap
                              </button>
                            </div>
                          </div>
                      )}
                    </div>

                  </div>
              )}

              {!isAuthenticated && (
                  <button onClick={() => navigate("/register")} className="hidden sm:flex items-center gap-2 bg-white hover:bg-gray-100 text-purple-700 px-5 py-2 rounded-full font-bold text-sm transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                    <PlusCircle size={18} />
                    <span>Ücretsiz İlan Ver</span>
                  </button>
              )}
            </div>
          </div>

          {/* Mobil Arama */}
          <div className="md:hidden pb-3">
            <div className="relative">
              <input
                  type="text"
                  placeholder="Arama yapın..."
                  className="w-full pl-3 pr-10 py-2 rounded outline-none text-sm focus:ring-2 focus:ring-purple-400"
              />
              <Search className="absolute right-3 top-2 text-gray-400" size={18} />
            </div>
          </div>
        </div>
      </header>
  )
}