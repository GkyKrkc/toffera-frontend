import { Routes, Route } from "react-router-dom"
import { AuthProvider } from "./store/AuthContext.jsx"
import { ToastProvider } from "./components/ui/Toast.jsx"
import HomePage from "./pages/HomePage.jsx"
import LoginPage from "./pages/LoginPage.jsx"
import RegisterPage from "./pages/RegisterPage.jsx"
import DashboardPage from "./pages/DashboardPage.jsx"
import AccountPage from "./pages/AccountPage.jsx"
import SettingsPage from "./pages/SettingsPage.jsx"
import PortfolioDashboard from "./pages/PortfolioDashboard.jsx"
import VehicleListPage from "./pages/portfolio/vehicle/VehicleListPage.jsx"
import VehicleFormPage from "./pages/portfolio/vehicle/VehicleFormPage.jsx"
import RealEstateListPage from "./pages/portfolio/realestate/RealEstateListPage.jsx"
import RealEstateFormPage from "./pages/portfolio/realestate/RealEstateFormPage.jsx"
import VehicleDemandPage from "./pages/demands/vehicle/index.jsx"

// Aşama 1: HomePage + Login/Register + Dashboard (Panelim) + Account
// (Profilim) + Settings (Ayarlar) + Portföy sistemi + Araç Talep Sihirbazı
// tam kurulu. Gayrimenkul Talep Sihirbazı, MarketPage ve DemandDetailPage
// sırayla eklenecek.
export default function App() {
    return (
        <AuthProvider>
            <ToastProvider>
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/dashboard" element={<DashboardPage />} />
                    <Route path="/account" element={<AccountPage />} />
                    <Route path="/settings" element={<SettingsPage />} />
                    <Route path="/portfolio" element={<PortfolioDashboard />} />
                    <Route path="/portfolio/vehicle" element={<VehicleListPage />} />
                    <Route path="/portfolio/vehicle/add" element={<VehicleFormPage />} />
                    <Route path="/portfolio/vehicle/:id/edit" element={<VehicleFormPage />} />
                    <Route path="/portfolio/realestate" element={<RealEstateListPage />} />
                    <Route path="/portfolio/realestate/add" element={<RealEstateFormPage />} />
                    <Route path="/portfolio/realestate/:id/edit" element={<RealEstateFormPage />} />
                    <Route path="/demands/create/vehicle" element={<VehicleDemandPage />} />
                    <Route path="/demands/create/new-vehicle" element={<VehicleDemandPage />} />
                    <Route path="/demands/create/used-vehicle" element={<VehicleDemandPage />} />
                </Routes>
            </ToastProvider>
        </AuthProvider>
    )
}