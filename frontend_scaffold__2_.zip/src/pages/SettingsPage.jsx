import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import {
    Bell, AlertTriangle, Smartphone, Mail,
    Phone, Eye, PauseCircle, Trash2, Loader2, ShieldCheck
} from "lucide-react"
import Header from "@/components/layout/Header"
import Toggle from "@/components/ui/Toggle"
import { useAuth } from "@/store/AuthContext"
import { useToast } from "@/components/ui/Toast"
import api from "@/lib/axios"

// NOT: Bildirim tercihleri ve gizlilik uç noktaları (/user/notification-preferences,
// /user/privacy, /user/deactivate, /user/account) backend'de henüz mevcut
// olmayabilir — bu sayfa arayüzü hazırlıyor, karşılık gelen Laravel route'ları
// eklenince alanlar gerçek veriyle senkron çalışacak. Şimdilik istek
// başarısız olursa arayüz sessizce yerel state ile devam ediyor.

const TABS = [
    { key: "notifications", label: "Bildirim Tercihleri", icon: Bell },
    { key: "privacy",       label: "Gizlilik",             icon: Eye },
    { key: "account",       label: "Hesap İşlemleri",       icon: AlertTriangle },
]

const NOTIFICATION_ROWS = [
    { key: "new_offer",       label: "Yeni Teklif Geldi",         desc: "Talebinize bir uzman teklif verdiğinde" },
    { key: "demand_status",   label: "Talep Durumu Değişti",      desc: "Talebiniz onaylandığında veya reddedildiğinde" },
    { key: "price_drop",      label: "Fiyat Düşüşü",              desc: "Favorilediğiniz ilanların fiyatı düştüğünde" },
    { key: "region_activity", label: "Takip Ettiğim Bölgede İlan", desc: "Takip ettiğiniz bölgelerde yeni talep girildiğinde" },
    { key: "security",        label: "Güvenlik Uyarıları",         desc: "Yeni cihazdan giriş gibi güvenlik olaylarında" },
]

// ── Bildirim Tercihleri Sekmesi ─────────────────────────────────
function NotificationTab() {
    const toast = useToast()
    const [prefs, setPrefs] = useState(() => {
        const initial = {}
        NOTIFICATION_ROWS.forEach(r => { initial[r.key] = { sms: true, email: true } })
        return initial
    })
    const [loading, setLoading] = useState(true)
    const [saving, setSaving] = useState(false)

    useEffect(() => {
        api.get("/user/notification-preferences")
            .then(res => { if (res.data) setPrefs(prev => ({ ...prev, ...res.data })) })
            .catch(() => {})
            .finally(() => setLoading(false))
    }, [])

    const toggle = (key, channel) => {
        setPrefs(prev => ({ ...prev, [key]: { ...prev[key], [channel]: !prev[key][channel] } }))
    }

    const handleSave = async () => {
        setSaving(true)
        try {
            await api.put("/user/notification-preferences", prefs)
            toast({ message: "Bildirim tercihleri kaydedildi." })
        } catch {
            toast({ message: "Kaydedilemedi, daha sonra tekrar deneyin.", type: "error" })
        } finally {
            setSaving(false)
        }
    }

    if (loading) {
        return (
            <div className="flex items-center justify-center py-10">
                <Loader2 size={18} className="animate-spin text-purple-500" />
            </div>
        )
    }

    return (
        <div>
            {/* Kolon başlıkları */}
            <div className="flex items-center gap-4 pb-2 mb-1 border-b border-gray-100">
                <div className="flex-1" />
                <div className="w-14 flex flex-col items-center gap-0.5">
                    <Smartphone size={12} className="text-gray-400" />
                    <span className="text-[8px] font-bold uppercase tracking-wider text-gray-400">SMS</span>
                </div>
                <div className="w-14 flex flex-col items-center gap-0.5">
                    <Mail size={12} className="text-gray-400" />
                    <span className="text-[8px] font-bold uppercase tracking-wider text-gray-400">E-posta</span>
                </div>
            </div>

            {NOTIFICATION_ROWS.map(row => (
                <div key={row.key} className="flex items-center gap-4 py-2.5 border-b border-gray-50 last:border-0">
                    <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-gray-800">{row.label}</p>
                        <p className="text-[10px] text-gray-400 font-medium mt-0.5">{row.desc}</p>
                    </div>
                    <div className="w-14 flex justify-center">
                        <Toggle checked={prefs[row.key]?.sms} onChange={() => toggle(row.key, "sms")} disabled={row.key === "security"} />
                    </div>
                    <div className="w-14 flex justify-center">
                        <Toggle checked={prefs[row.key]?.email} onChange={() => toggle(row.key, "email")} disabled={row.key === "security"} />
                    </div>
                </div>
            ))}

            <button onClick={handleSave} disabled={saving}
                    className="mt-4 flex items-center justify-center gap-2 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-800 hover:to-indigo-700 disabled:opacity-60 text-white px-4 py-2.5 rounded font-bold text-xs uppercase tracking-wider transition-all">
                {saving ? <Loader2 size={13} className="animate-spin" /> : null}
                {saving ? "Kaydediliyor..." : "Tercihleri Kaydet"}
            </button>
        </div>
    )
}

// ── Gizlilik Sekmesi ────────────────────────────────────────────
function PrivacyTab() {
    const toast = useToast()
    const [phoneVisible, setPhoneVisible] = useState(false)
    const [emailVisible, setEmailVisible] = useState(false)
    const [loading, setLoading] = useState(true)
    const [saving, setSaving] = useState(false)

    useEffect(() => {
        api.get("/user/privacy")
            .then(res => {
                setPhoneVisible(!!res.data?.phone_visible)
                setEmailVisible(!!res.data?.email_visible)
            })
            .catch(() => {})
            .finally(() => setLoading(false))
    }, [])

    const handleSave = async () => {
        setSaving(true)
        try {
            await api.put("/user/privacy", { phone_visible: phoneVisible, email_visible: emailVisible })
            toast({ message: "Gizlilik ayarları kaydedildi." })
        } catch {
            toast({ message: "Kaydedilemedi, daha sonra tekrar deneyin.", type: "error" })
        } finally {
            setSaving(false)
        }
    }

    if (loading) {
        return (
            <div className="flex items-center justify-center py-10">
                <Loader2 size={18} className="animate-spin text-purple-500" />
            </div>
        )
    }

    return (
        <div className="space-y-1">
            <div className="flex items-center gap-3 py-2.5 border-b border-gray-50">
                <Phone size={15} className="text-gray-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-gray-800">Telefon Numaramı Göster</p>
                    <p className="text-[10px] text-gray-400 font-medium mt-0.5">
                        Kapalıyken numaranız yalnızca kabul ettiğiniz teklif sahibiyle paylaşılır.
                    </p>
                </div>
                <Toggle checked={phoneVisible} onChange={setPhoneVisible} />
            </div>

            <div className="flex items-center gap-3 py-2.5">
                <Mail size={15} className="text-gray-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-gray-800">E-posta Adresimi Göster</p>
                    <p className="text-[10px] text-gray-400 font-medium mt-0.5">
                        Kapalıyken e-postanız diğer kullanıcılara gösterilmez.
                    </p>
                </div>
                <Toggle checked={emailVisible} onChange={setEmailVisible} />
            </div>

            <button onClick={handleSave} disabled={saving}
                    className="mt-3 flex items-center justify-center gap-2 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-800 hover:to-indigo-700 disabled:opacity-60 text-white px-4 py-2.5 rounded font-bold text-xs uppercase tracking-wider transition-all">
                {saving ? <Loader2 size={13} className="animate-spin" /> : null}
                {saving ? "Kaydediliyor..." : "Ayarları Kaydet"}
            </button>
        </div>
    )
}

// ── Hesap İşlemleri Sekmesi ──────────────────────────────────────
function AccountActionsTab() {
    const toast = useToast()
    const { logout } = useAuth()
    const navigate = useNavigate()
    const [deactivating, setDeactivating] = useState(false)
    const [deleting, setDeleting] = useState(false)

    const handleDeactivate = async () => {
        if (!confirm("Hesabınızı dondurmak istediğinizden emin misiniz? Tekrar giriş yaptığınızda hesabınız otomatik olarak aktifleşir.")) return
        setDeactivating(true)
        try {
            await api.post("/user/deactivate")
            toast({ message: "Hesabınız donduruldu." })
            await logout()
            navigate("/")
        } catch {
            toast({ message: "İşlem başarısız oldu.", type: "error" })
        } finally {
            setDeactivating(false)
        }
    }

    const handleDelete = async () => {
        const confirmed = confirm("Hesabınızı KALICI OLARAK silmek üzeresiniz. Bu işlem geri alınamaz, tüm talep/portföy/teklif verileriniz silinir. Devam etmek istiyor musunuz?")
        if (!confirmed) return
        const doubleCheck = prompt('Onaylamak için kutuya "SİL" yazın:')
        if (doubleCheck !== "SİL") return

        setDeleting(true)
        try {
            await api.delete("/user/account")
            toast({ message: "Hesabınız silindi." })
            await logout()
            navigate("/")
        } catch {
            toast({ message: "İşlem başarısız oldu.", type: "error" })
        } finally {
            setDeleting(false)
        }
    }

    return (
        <div className="space-y-3">
            <div className="flex items-center gap-3 justify-between p-3 bg-gray-50 border border-gray-200 rounded-sm">
                <div className="flex items-center gap-2.5 min-w-0">
                    <PauseCircle size={16} className="text-amber-500 flex-shrink-0" />
                    <div className="min-w-0">
                        <p className="text-xs font-bold text-gray-800">Hesabımı Dondur</p>
                        <p className="text-[10px] text-gray-400 font-medium mt-0.5">İlanlarınız gizlenir, tekrar giriş yapınca aktifleşir.</p>
                    </div>
                </div>
                <button onClick={handleDeactivate} disabled={deactivating}
                        className="flex-shrink-0 flex items-center gap-1.5 bg-white border border-amber-200 text-amber-700 hover:bg-amber-50 disabled:opacity-60 px-3 py-2 rounded font-bold text-[11px] transition-all">
                    {deactivating ? <Loader2 size={12} className="animate-spin" /> : null}
                    Dondur
                </button>
            </div>

            <div className="flex items-center gap-3 justify-between p-3 bg-red-50/40 border border-red-100 rounded-sm">
                <div className="flex items-center gap-2.5 min-w-0">
                    <Trash2 size={16} className="text-red-500 flex-shrink-0" />
                    <div className="min-w-0">
                        <p className="text-xs font-bold text-gray-800">Hesabımı Kalıcı Olarak Sil</p>
                        <p className="text-[10px] text-gray-400 font-medium mt-0.5">Bu işlem geri alınamaz, tüm verileriniz silinir.</p>
                    </div>
                </div>
                <button onClick={handleDelete} disabled={deleting}
                        className="flex-shrink-0 flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white disabled:opacity-60 px-3 py-2 rounded font-bold text-[11px] transition-all">
                    {deleting ? <Loader2 size={12} className="animate-spin" /> : null}
                    Sil
                </button>
            </div>
        </div>
    )
}

// ── Ana Sayfa ─────────────────────────────────────────────────
export default function SettingsPage() {
    const { user, isAuthenticated, loading: authLoading } = useAuth()
    const navigate = useNavigate()
    const [activeTab, setActiveTab] = useState("notifications")

    useEffect(() => {
        if (!authLoading && !isAuthenticated) navigate("/")
    }, [authLoading, isAuthenticated])

    if (authLoading) {
        return (
            <div className="min-h-screen bg-gray-100 flex flex-col">
                <Header />
                <div className="flex items-center justify-center flex-1">
                    <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
                </div>
            </div>
        )
    }

    if (!isAuthenticated) return null

    return (
        <div className="min-h-screen bg-gray-100 font-sans text-gray-800 flex flex-col">
            <Header />

            <main className="max-w-[1200px] mx-auto w-full px-4 py-6 flex-1">

                {/* Başlık */}
                <div className="mb-6">
                    <h1 className="text-xl font-bold text-gray-800">Ayarlar</h1>
                    <p className="text-gray-400 text-xs font-medium mt-1">Bildirim, gizlilik ve hesap tercihlerinizi yönetin</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

                    {/* Sol sidebar — tab menü */}
                    <div className="md:col-span-1">
                        <div className="bg-white rounded-sm border border-gray-200 shadow-sm overflow-hidden">
                            {TABS.map(tab => {
                                const Icon = tab.icon
                                const isDanger = tab.key === "account"
                                return (
                                    <button key={tab.key}
                                            onClick={() => setActiveTab(tab.key)}
                                            className={`w-full flex items-center gap-2.5 px-4 py-3 text-left border-b border-gray-100 last:border-0 transition-all ${
                                                activeTab === tab.key
                                                    ? isDanger ? "bg-red-50 text-red-700" : "bg-purple-50 text-purple-700"
                                                    : "text-gray-600 hover:bg-gray-50"
                                            }`}>
                                        <Icon size={14} className={activeTab === tab.key ? (isDanger ? "text-red-500" : "text-purple-600") : "text-gray-400"} />
                                        <span className="text-xs font-bold">{tab.label}</span>
                                    </button>
                                )
                            })}
                        </div>

                        <div className="mt-4 flex items-start gap-2.5 px-4 py-3 bg-purple-50 border border-purple-100 rounded-sm hidden md:flex">
                            <ShieldCheck size={13} className="text-purple-500 mt-0.5 flex-shrink-0" />
                            <p className="text-[10px] text-purple-700 font-semibold leading-relaxed">
                                Şifre değiştirme "Profilim" sayfasındaki Güvenlik sekmesinden yönetilir.
                            </p>
                        </div>
                    </div>

                    {/* Sağ içerik */}
                    <div className="md:col-span-3">
                        <div className={`bg-white rounded-sm border shadow-sm p-5 ${activeTab === "account" ? "border-red-100" : "border-gray-200"}`}>
                            {activeTab === "notifications" && <NotificationTab />}
                            {activeTab === "privacy"       && <PrivacyTab />}
                            {activeTab === "account"       && <AccountActionsTab />}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    )
}