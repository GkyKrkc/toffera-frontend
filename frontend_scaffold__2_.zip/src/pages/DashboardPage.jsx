import { useState, useEffect } from "react"
import { useNavigate, Link } from "react-router-dom"
import { useAuth } from "@/store/AuthContext"
import Header from "@/components/layout/Header"
import BuyerDashboard from "@/components/dashboard/BuyerDashboard"
import AgentDashboard from "@/components/dashboard/AgentDashboard"
import {
    Clock, CheckCircle, ExternalLink, ShieldAlert, ShieldCheck,
    User, Bell, ChevronRight, Package, TrendingUp, Award, Send,
    ArrowUpRight, ArrowDownRight, HelpCircle, Info, LayoutDashboard
} from "lucide-react"

const TABS = [
    { key: "overview",      label: "Genel Bakış",             icon: LayoutDashboard },
    { key: "profile",       label: "Profilim",                icon: User            },
    { key: "notifications", label: "Bildirimler",              icon: Bell            },
    { key: "guide",         label: "Güvenli İşlem Rehberi",    icon: HelpCircle      },
]

// Canlı Bölgesel Fiyat Endeksi — şimdilik simüle veri, endeks API'si
// bağlanınca sadece setIndexData kaynağı değişecek.
function LiveMarketIndexWidget() {
    const [indexData, setIndexData] = useState({
        emlak: { index: 1245.2, diff: 1.45, dir: "up" },
        vasita: { index: 942.8, diff: -0.22, dir: "down" },
        talepYogunluk: { index: 88.5, diff: 3.12, dir: "up" },
    })

    useEffect(() => {
        const interval = setInterval(() => {
            setIndexData(prev => {
                const e = (Math.random() - 0.45) * 0.8
                const v = (Math.random() - 0.52) * 0.6
                const y = (Math.random() - 0.4) * 0.5
                return {
                    emlak: { index: +(prev.emlak.index + e).toFixed(1), diff: +(prev.emlak.diff + e / 10).toFixed(2), dir: e >= 0 ? "up" : "down" },
                    vasita: { index: +(prev.vasita.index + v).toFixed(1), diff: +(prev.vasita.diff + v / 10).toFixed(2), dir: v >= 0 ? "up" : "down" },
                    talepYogunluk: { index: +(prev.talepYogunluk.index + y).toFixed(1), diff: +(prev.talepYogunluk.diff + y / 10).toFixed(2), dir: y >= 0 ? "up" : "down" },
                }
            })
        }, 3000)
        return () => clearInterval(interval)
    }, [])

    const rows = [
        { label: "Gayrimenkul Endeksi", val: `${indexData.emlak.index} TL / m²`, d: indexData.emlak },
        { label: "Oto-Fiyat Endeksi", val: `${indexData.vasita.index} Puan`, d: indexData.vasita },
        { label: "Günlük Talep İvmesi", val: `${indexData.talepYogunluk.index} Yoğunluk`, d: indexData.talepYogunluk },
    ]

    return (
        <div className="border border-gray-200 rounded-sm overflow-hidden">
            <div className="border-b border-gray-200 bg-gray-50 px-4 py-2.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <TrendingUp size={14} className="text-purple-600" />
                    <h2 className="text-xs font-bold text-gray-800">Bölgesel Fiyat Endeksi</h2>
                </div>
                <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
          <span className="text-[9px] font-bold uppercase text-green-700">Canlı</span>
        </span>
            </div>
            <div className="p-4 space-y-3">
                {rows.map((r, i) => (
                    <div key={i} className={`flex items-center justify-between ${i < rows.length - 1 ? "border-b border-gray-100 pb-3" : ""}`}>
                        <div>
                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">{r.label}</p>
                            <p className="text-xs font-bold text-gray-800 mt-0.5">{r.val}</p>
                        </div>
                        <div className={`flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded ${r.d.dir === "up" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
                            {r.d.dir === "up" ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                            %{Math.abs(r.d.diff).toFixed(2)}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

// ── Genel Bakış Sekmesi ──────────────────────────────────────
function OverviewTab({ isBuyer, isAgent, isAdmin, navigate, onStatsChange }) {
    return (
        <div className="space-y-6">
            {isBuyer && <BuyerDashboard onCreateDemand={() => navigate("/demands/create")} />}
            {isAgent && <AgentDashboard onGoToMarket={() => navigate("/market")} onStatsChange={onStatsChange} />}
            {isAdmin && (
                <div className="text-center py-10">
                    <ShieldAlert className="w-9 h-9 text-red-600 mx-auto mb-3" />
                    <p className="text-xs font-bold text-gray-700 uppercase tracking-wider">Yönetim Modu Aktif</p>
                    <p className="text-[11px] text-gray-400 font-medium mt-1">İşlemleri admin paneli üzerinden yürütebilirsiniz.</p>
                </div>
            )}
            {!isBuyer && !isAgent && !isAdmin && (
                <div className="text-center py-16">
                    <p className="text-sm font-bold text-gray-600">Gösterilecek içerik bulunamadı.</p>
                </div>
            )}

            <LiveMarketIndexWidget />
        </div>
    )
}

// ── Profilim Sekmesi (özet) ──────────────────────────────────
function ProfileSummaryTab({ user, isAgent, isBuyer }) {
    return (
        <div className="space-y-3 text-left">
            <div className="flex items-center gap-3 border-b border-gray-100 pb-4 mb-1">
                <div className="w-11 h-11 rounded bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600 flex-shrink-0">
                    <User size={18} />
                </div>
                <div className="min-w-0">
                    <p className="text-xs font-bold text-gray-800 truncate">{user?.company_name || user?.name || "Kullanıcı"}</p>
                    <p className="text-[10px] font-medium text-gray-400 truncate mt-0.5">{user?.email || user?.phone}</p>
                </div>
            </div>

            <div className="flex items-center justify-between text-xs border-b border-gray-50 pb-2">
                <span className="text-gray-400 font-medium">Hesap Türü</span>
                <span className="font-bold text-gray-800">
          {isAgent ? "Lisanslı Uzman" : isBuyer ? "Alıcı / Müşteri" : "Yönetici"}
        </span>
            </div>

            <div className="flex items-center justify-between text-xs border-b border-gray-50 pb-2">
                <span className="text-gray-400 font-medium">Hesap Durumu</span>
                {user?.status === "active" ? (
                    <span className="flex items-center gap-1 text-[9px] font-bold text-green-700 bg-green-50 border border-green-100 px-2 py-0.5 rounded">
            <CheckCircle size={9} /> AKTİF
          </span>
                ) : (
                    <span className="flex items-center gap-1 text-[9px] font-bold text-amber-700 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded">
            <Clock size={9} /> ONAY BEKLİYOR
          </span>
                )}
            </div>

            {isAgent && (
                <div className="flex items-center justify-between text-xs border-b border-gray-50 pb-2">
                    <span className="text-gray-400 font-medium">Üyelik Modeli</span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider border ${
                        user?.subscription_plan && user?.subscription_plan !== "free"
                            ? "bg-purple-50 text-purple-700 border-purple-100"
                            : "bg-gray-50 text-gray-500 border-gray-200"
                    }`}>
            <Award size={10} /> {user?.subscription_plan && user?.subscription_plan !== "free" ? "PREMIUM" : "ÜCRETSİZ"}
          </span>
                </div>
            )}

            {isAgent && user?.subscription_plan === "free" && (
                <p className="text-[10px] text-gray-500 font-medium leading-relaxed pt-1">
                    Aylık {user?.offer_limit || 3} teklif hakkınız aktif.
                </p>
            )}

            {isAgent && (
                <div className="bg-purple-50 border border-purple-100 rounded-sm p-3 text-left mt-1">
                    <div className="flex items-center gap-2 mb-1">
                        <ShieldCheck size={13} className="text-purple-700" />
                        <span className="text-[10px] font-bold text-purple-900 uppercase tracking-wide">Acente Akreditasyonu</span>
                    </div>
                    <p className="text-[10px] text-gray-500 font-medium leading-relaxed">
                        Platformda yayınlanan tüm taleplere resmi lisansınız ile anında teklif verebilirsiniz.
                    </p>
                </div>
            )}

            {isAgent && user?.subscription_plan === "free" && (
                <button className="mt-1 w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-800 hover:to-indigo-700 text-white px-4 py-2 rounded font-bold text-xs uppercase tracking-wider transition-all">
                    <TrendingUp size={12} /> Planı Yükselt
                </button>
            )}
        </div>
    )
}

// ── Bildirimler Sekmesi (özet) ────────────────────────────────
function NotificationsSummaryTab({ navigate }) {
    return (
        <div>
            <div className="flex items-center justify-between mb-3">
                <div className="w-9 h-9 rounded bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
                    <Bell size={15} />
                </div>
                <span className="flex items-center gap-1 text-[8px] font-bold text-green-700 bg-green-50 border border-green-100 px-1.5 py-0.5 rounded">
          <span className="w-1 h-1 rounded-full bg-green-500 animate-pulse" /> CANLI
        </span>
            </div>
            <p className="text-xs font-bold text-gray-800 mb-1">Bildirim Akışı</p>
            <p className="text-[11px] text-gray-500 font-medium leading-relaxed mb-3">
                Yeni teklif, talep eşleşmesi veya durum değişikliklerinde anlık olarak burada bilgilendirilirsiniz.
            </p>
            <button onClick={() => navigate("/notifications")}
                    className="w-full flex items-center justify-center gap-1.5 py-2 text-[10px] font-bold uppercase tracking-wider text-gray-600 hover:text-gray-900 border border-gray-200 hover:border-gray-300 rounded transition-all bg-gray-50 hover:bg-gray-100">
                Tümünü Gör <ChevronRight size={12} />
            </button>
        </div>
    )
}

// ── Güvenli İşlem Rehberi Sekmesi ────────────────────────────
function GuideTab() {
    return (
        <div className="space-y-4 text-[11px] text-gray-600 text-left">
            <div className="flex items-center gap-2 mb-1">
                <HelpCircle size={14} className="text-purple-600" />
                <h3 className="text-xs font-bold text-gray-800">Güvenli İşlem Rehberi</h3>
            </div>
            <div className="space-y-1">
                <p className="font-bold text-gray-800">Ruhsatlı Uzman Garantisi</p>
                <p className="leading-relaxed">Tüm gayrimenkul ve vasıta uzmanlarımız mesleki liyakat ve ruhsat kontrolünden geçirilir.</p>
            </div>
            <div className="space-y-1">
                <p className="font-bold text-gray-800">KVKK Gizlilik Kalkanı</p>
                <p className="leading-relaxed">İletişim bilgileriniz asla satıcılarla paylaşılmaz; sadece kabul ettiğiniz teklif sahibiyle görüşürsünüz.</p>
            </div>
            <div className="space-y-1">
                <p className="font-bold text-gray-800">Sıfır Ek Komisyon</p>
                <p className="leading-relaxed">Taraflar arasında gerçekleşen satışlardan ek platform hizmet bedeli alınmaz.</p>
            </div>
        </div>
    )
}

export default function DashboardPage() {
    const { user, isAuthenticated, isAgent, isBuyer, isAdmin, loading } = useAuth()
    const navigate = useNavigate()
    const [agentStats, setAgentStats] = useState(null)
    const [activeTab, setActiveTab] = useState("overview")

    useEffect(() => {
        if (!loading && !isAuthenticated) navigate("/")
    }, [loading, isAuthenticated])

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-100 flex flex-col">
                <Header />
                <div className="flex items-center justify-center flex-1">
                    <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
                </div>
            </div>
        )
    }

    if (!isAuthenticated) return null

    return (
        <div className="min-h-screen bg-gray-100 font-sans text-gray-800 flex flex-col">
            <Header />

            <main className="max-w-[1200px] mx-auto w-full px-4 py-6 flex-1">

                {/* Üst Başlık */}
                <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <p className="text-[9px] font-bold text-purple-700 uppercase tracking-wider mb-1">
                            {isAgent ? "Uzman Danışman Paneli" : isBuyer ? "Müşteri Kontrol Paneli" : "Yönetim Merkezi"}
                        </p>
                        <h1 className="text-xl font-bold text-gray-800">Merhaba, {user?.name?.split(" ")[0]}</h1>
                        <p className="text-gray-400 text-xs font-medium mt-1">
                            {isAgent ? "Teklifleriniz, güncel portföyünüz ve gelen talep akışını yönetin." :
                                isBuyer ? "Oluşturduğunuz talepleri ve gelen akredite teklifleri takip edin." :
                                    "TOFFERA sistem kontrol ve operasyon yönetim merkezi."}
                        </p>

                        {isAgent && agentStats && (
                            <div className="flex flex-wrap items-center gap-1.5 mt-3">
                <span className="inline-flex items-center gap-1 text-[9px] font-bold px-2 py-1 rounded border bg-purple-50 text-purple-700 border-purple-100">
                  <Send size={10} /> {agentStats.total} Teklif
                </span>
                                <span className="inline-flex items-center gap-1 text-[9px] font-bold px-2 py-1 rounded border bg-green-50 text-green-700 border-green-100">
                  <CheckCircle size={10} /> {agentStats.accepted} Kabul
                </span>
                                <span className="inline-flex items-center gap-1 text-[9px] font-bold px-2 py-1 rounded border bg-amber-50 text-amber-700 border-amber-100">
                  <Award size={10} />
                                    {agentStats.activeSubscription
                                        ? (agentStats.activeSubscription.offer_quota == null
                                            ? "Sınırsız Kota"
                                            : `${agentStats.activeSubscription.offers_remaining}/${agentStats.activeSubscription.offer_quota} Kota`)
                                        : `${agentStats.creditBalance ?? 0} Kontör`}
                </span>
                            </div>
                        )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                        {user?.status === "pending" && (
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded text-[9px] text-amber-800 font-bold uppercase tracking-wider">
                                <Clock size={11} className="text-amber-500" /> Onay Bekleniyor
                            </div>
                        )}
                        {user?.status === "active" && (
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 border border-green-200 rounded text-[9px] text-green-800 font-bold uppercase tracking-wider">
                                <span className="w-1.5 h-1.5 bg-green-500 rounded-full" /> Doğrulanmış Hesap
                            </div>
                        )}
                        {isAgent && (
                            <Link to="/portfolio"
                                  className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-800 hover:to-indigo-700 text-white rounded text-[9px] font-bold uppercase tracking-wider transition-all shadow-sm">
                                <Package size={11} /> Aktif Stok Portföyüm
                            </Link>
                        )}
                    </div>
                </div>

                {/* Sistem Yönetici Paneli */}
                {isAdmin && (
                    <div className="mb-6 bg-gray-900 p-5 text-white border border-gray-800 rounded-sm shadow-sm">
                        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                            <div className="space-y-2 text-left">
                                <div className="inline-flex items-center gap-1.5 bg-red-500/10 border border-red-500/20 text-red-400 px-2.5 py-1 rounded text-[9px] font-bold uppercase tracking-wider">
                                    <ShieldAlert size={11} /> Sistem Yöneticisi
                                </div>
                                <h2 className="text-base font-bold text-white">Yönetim ve Filament Konsolu</h2>
                                <p className="text-gray-400 text-xs font-medium max-w-lg">
                                    Kullanıcı onayları, acente başvuruları ve sistem ayarları için Filament kontrol merkezine geçiş yapın.
                                </p>
                            </div>
                            <a href="/admin" target="_blank" rel="noopener noreferrer"
                               className="inline-flex items-center gap-2 px-4 py-2 bg-white hover:bg-red-50 text-red-700 font-bold text-xs uppercase tracking-wider rounded transition-all shadow-sm w-full md:w-auto justify-center">
                                <ExternalLink size={13} /> Admin Panele Git
                            </a>
                        </div>
                    </div>
                )}

                {/* Sol Sidebar + Sağ İçerik */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

                    {/* Sol sidebar — tab menü */}
                    <div className="md:col-span-1">
                        <div className="bg-white rounded-sm border border-gray-200 shadow-sm overflow-hidden">
                            {TABS.map(tab => {
                                const Icon = tab.icon
                                return (
                                    <button key={tab.key}
                                            onClick={() => setActiveTab(tab.key)}
                                            className={`w-full flex items-center gap-2.5 px-4 py-3 text-left border-b border-gray-100 last:border-0 transition-all ${
                                                activeTab === tab.key ? "bg-purple-50 text-purple-700" : "text-gray-600 hover:bg-gray-50"
                                            }`}>
                                        <Icon size={14} className={activeTab === tab.key ? "text-purple-600" : "text-gray-400"} />
                                        <span className="text-xs font-bold">{tab.label}</span>
                                    </button>
                                )
                            })}
                        </div>

                        {/* Mobilde gizli, masaüstünde özet kart */}
                        <div className="mt-4 bg-gray-900 border border-gray-800 rounded-sm shadow-sm p-4 hidden md:block">
                            <div className="flex items-center gap-2 mb-2">
                                <Info size={12} className="text-amber-400" />
                                <span className="text-[9px] font-bold uppercase tracking-wide text-white">Bilgi</span>
                            </div>
                            <p className="text-[10px] text-gray-300 leading-relaxed">
                                Panel sekmelerinden hesap durumunuzu, bildirim akışını ve güvenli işlem rehberini takip edebilirsiniz.
                            </p>
                        </div>
                    </div>

                    {/* Sağ içerik */}
                    <div className="md:col-span-3">
                        <div className="bg-white rounded-sm border border-gray-200 shadow-sm p-5">
                            {activeTab === "overview" && (
                                <OverviewTab isBuyer={isBuyer} isAgent={isAgent} isAdmin={isAdmin} navigate={navigate} onStatsChange={setAgentStats} />
                            )}
                            {activeTab === "profile" && <ProfileSummaryTab user={user} isAgent={isAgent} isBuyer={isBuyer} />}
                            {activeTab === "notifications" && <NotificationsSummaryTab navigate={navigate} />}
                            {activeTab === "guide" && <GuideTab />}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    )
}