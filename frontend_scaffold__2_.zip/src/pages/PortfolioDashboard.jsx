import { useState, useEffect, useMemo } from "react"
import { useNavigate, Link } from "react-router-dom"
import {
    Car, Building2, Plus, Package,
    ChevronRight, BarChart2, ShieldCheck,
    TrendingUp, Tag, CheckCircle
} from "lucide-react"
import Header from "@/components/layout/Header"
import { useAuth } from "@/store/AuthContext"
import api from "@/lib/axios"

const ALL_CATEGORIES = [
    {
        key: "vasita", types: ["galerici", "her_ikisi"],
        label: "Vasıta Portföyü", desc: "Araç stok yönetimi",
        icon: Car, color: "text-purple-700", bg: "bg-purple-50", border: "border-purple-100",
        accent: "#7e22ce", route: "/portfolio/vehicle",
    },
    {
        key: "gayrimenkul", types: ["emlakci", "her_ikisi"],
        label: "Gayrimenkul Portföyü", desc: "Mülk stok yönetimi",
        icon: Building2, color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-100",
        accent: "#d97706", route: "/portfolio/realestate",
    },
]

const ROLE_LABELS = {
    emlakci: "Emlak Uzmanı",
    galerici: "Vasıta Uzmanı",
    her_ikisi: "Emlak & Vasıta",
}

export default function PortfolioDashboard() {
    const { user, isAuthenticated, loading: authLoading } = useAuth()
    const navigate = useNavigate()
    const [stats, setStats] = useState(null)
    const [loading, setLoading] = useState(true)

    const agentType = user?.agent_type || user?.account_type || ""

    useEffect(() => {
        if (authLoading) return
        if (!isAuthenticated) { navigate("/"); return }

        // Tek kategorili uzmanları direkt sayfaya yönlendir
        if (agentType === "emlakci")  { navigate("/portfolio/realestate", { replace: true }); return }
        if (agentType === "galerici") { navigate("/portfolio/vehicle",    { replace: true }); return }

        // 'her_ikisi' uzmanlar VE agent_type'ı olmayan (bireysel) kullanıcılar
        // burada kalır — bireysel kullanıcı hem araç hem ev satabileceği için
        // tek bir uzmanlığa kısıtlanmıyor, ikisini de görür.
        api.get("/agent/portfolio/stats")
            .then(r => setStats(r.data))
            .catch(() => {})
            .finally(() => setLoading(false))
    }, [agentType, authLoading, isAuthenticated])

    const categories = useMemo(() =>
            ALL_CATEGORIES.filter(c => !agentType || c.types.includes(agentType)),
        [agentType]
    )

    const total     = stats?.total     ?? 0
    const available = stats?.available ?? 0
    const reserved  = stats?.reserved  ?? 0
    const sold      = stats?.sold      ?? 0

    // Tek kategori uzmanları yönlendirilirken boş render.
    if (agentType === "emlakci" || agentType === "galerici") return null

    return (
        <div className="min-h-screen bg-gray-100 font-sans text-gray-800 flex flex-col">
            <Header />

            <main className="max-w-[1200px] mx-auto w-full px-4 py-6 flex-1">

                {/* Başlık + Kontroller */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                    <div>
            <span className="inline-flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 border border-purple-100 px-2.5 py-1 rounded-full mb-2">
              <ShieldCheck size={9} /> {ROLE_LABELS[agentType] || "Bireysel Satıcı"}
            </span>
                        <h1 className="text-xl font-bold text-gray-800">Portföy Paneli</h1>
                        <p className="text-gray-400 text-xs font-medium mt-0.5">
                            Stoğunuzu yönetin. Gelen taleplere otomatik eşleşin.
                            {total > 0 && !loading && <span className="ml-2 font-bold text-purple-700">{total} kayıt</span>}
                        </p>
                    </div>

                    <Link to="/dashboard"
                          className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider text-gray-500 hover:text-purple-700 border border-gray-200 hover:border-purple-200 bg-white px-3 py-2 rounded transition-all shadow-sm w-full sm:w-auto justify-center sm:justify-start">
                        <ChevronRight size={11} className="rotate-180" /> Ana Panel
                    </Link>
                </div>

                {/* Özet kutuları */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                    {[
                        { label: "Toplam Stok", value: total,     icon: Package,     color: "text-gray-800",  iconBg: "bg-purple-50", iconColor: "text-purple-600" },
                        { label: "Satışta",      value: available, icon: TrendingUp,  color: "text-green-700",  iconBg: "bg-green-50",  iconColor: "text-green-600", dot: true },
                        { label: "Rezerve",      value: reserved,  icon: Tag,         color: "text-amber-700",  iconBg: "bg-amber-50",  iconColor: "text-amber-600" },
                        { label: "Satılan",      value: sold,      icon: CheckCircle, color: "text-gray-700",   iconBg: "bg-gray-100",  iconColor: "text-gray-500" },
                    ].map((s, i) => {
                        const Icon = s.icon
                        return (
                            <div key={i} className="bg-white border border-gray-200 rounded-sm shadow-sm p-4">
                                <div className="flex items-center justify-between mb-3">
                                    <div className={`w-8 h-8 rounded flex items-center justify-center ${s.iconBg} ${s.iconColor}`}>
                                        <Icon size={14} />
                                    </div>
                                    {s.dot && <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />}
                                </div>
                                {loading
                                    ? <div className="h-8 w-12 bg-gray-100 rounded animate-pulse mb-1" />
                                    : <p className={`text-2xl font-bold leading-none mb-1 ${s.color}`}>{s.value}</p>}
                                <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">{s.label}</p>
                            </div>
                        )
                    })}
                </div>

                {/* İki Kolonlu Kategori Grid'i */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 mb-6">
                    {categories.map(cat => {
                        const Icon  = cat.icon
                        const count = stats?.by_type?.[cat.key] ?? 0
                        const pct   = total > 0 ? Math.round((count / total) * 100) : 0
                        return (
                            <div key={cat.key}
                                 className="lg:col-span-6 bg-white border border-gray-200 rounded-sm shadow-sm overflow-hidden hover:border-gray-300 transition-all flex flex-col">
                                <div className="h-[3px]" style={{ background: cat.accent }} />

                                <div className={`px-5 pt-5 pb-5 ${cat.bg}`}>
                                    <div className="flex items-start justify-between">
                                        <div className={`w-11 h-11 rounded bg-white border ${cat.border} flex items-center justify-center ${cat.color} shadow-sm`}>
                                            <Icon size={20} />
                                        </div>
                                        <div className="text-right">
                                            {loading
                                                ? <div className="h-9 w-14 bg-white/60 rounded animate-pulse" />
                                                : <p className={`text-3xl font-bold leading-none ${cat.color}`}>{count}</p>}
                                            <p className="text-[8px] font-bold text-gray-500 uppercase tracking-wider mt-1">Kayıt</p>
                                        </div>
                                    </div>

                                    <div className="mt-3">
                                        <p className={`text-sm font-bold ${cat.color}`}>{cat.label}</p>
                                        <p className="text-[11px] text-gray-500 font-medium mt-0.5">{cat.desc}</p>
                                    </div>

                                    {!loading && total > 0 && (
                                        <div className="mt-3">
                                            <div className="flex items-center justify-between mb-1.5">
                                                <span className="text-[8px] font-bold text-gray-500 uppercase tracking-wider">Toplam stoktaki payı</span>
                                                <span className={`text-[10px] font-bold ${cat.color}`}>%{pct}</span>
                                            </div>
                                            <div className="w-full bg-white/60 rounded-full h-1.5 overflow-hidden">
                                                <div className="h-1.5 rounded-full transition-all duration-1000" style={{ width: `${pct}%`, background: cat.accent }} />
                                            </div>
                                        </div>
                                    )}
                                </div>

                                <div className="flex gap-2 p-3 bg-white border-t border-gray-100 mt-auto">
                                    <Link to={cat.route}
                                          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 text-[9px] font-bold uppercase tracking-wider text-gray-600 hover:text-gray-900 border border-gray-200 hover:border-gray-300 rounded transition-all bg-gray-50 hover:bg-gray-100">
                                        <Package size={12} /> Listeyi Gör
                                    </Link>
                                    <Link to={`${cat.route}/add`}
                                          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 text-[9px] font-bold uppercase tracking-wider text-white rounded transition-all hover:opacity-90 shadow-sm"
                                          style={{ background: cat.accent }}>
                                        <Plus size={12} /> Yeni Ekle
                                    </Link>
                                </div>
                            </div>
                        )
                    })}
                </div>

                {/* Bilgi kutusu */}
                <div className="bg-white border border-gray-200 rounded-sm shadow-sm p-4 flex items-start gap-3">
                    <div className="w-9 h-9 bg-purple-50 border border-purple-100 rounded flex items-center justify-center text-purple-600 flex-shrink-0">
                        <BarChart2 size={16} />
                    </div>
                    <div>
                        <p className="text-xs font-bold text-gray-800 mb-1 flex items-center gap-2">
                            Portföy Eşleşme Sistemi Aktif
                            <span className="flex items-center gap-1 text-[8px] font-bold text-green-700 bg-green-50 border border-green-100 px-1.5 py-0.5 rounded-full">
                <span className="w-1 h-1 rounded-full bg-green-500 animate-pulse" /> CANLI
              </span>
                        </p>
                        <p className="text-[11px] text-gray-500 font-medium leading-relaxed">
                            Stoğunuzdaki ürünlere benzer bir müşteri talebi girildiğinde sistem otomatik olarak sizi bilgilendirir.
                            Portföyünüzü güncel tutun, daha fazla müşteriye ulaşın.
                        </p>
                    </div>
                </div>
            </main>
        </div>
    )
}