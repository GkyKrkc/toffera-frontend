import { useState, useEffect, useRef } from "react"
import { useNavigate } from "react-router-dom"
import { useTurkiyeLocation } from "@/hooks/useTurkiyeLocation"
import Header from "@/components/layout/Header"
import { 
  Search, User, MessageSquare,
  Home, Car, ShoppingBag, Briefcase, Wrench, 
  ChevronRight, Heart, MapPin, Menu, X, Building2, Laptop,
  LayoutGrid, List, Filter, Star, Phone, ShieldCheck, ChevronLeft,
  Tag, ChevronDown
} from 'lucide-react';

// --- MOCK DATA (Sahte Veriler) ---
const CATEGORIES = [
  { 
    id: 1, name: 'Gayrimenkul', icon: Building2, count: '1.245.320',
    subCategories: [
      {
        id: 11, name: 'Satılık', count: '850.000',
        subCategories: [
          { id: 111, name: 'Ev / Daire', count: '450.000' },
          { id: 112, name: 'Arsa / Tarla', count: '350.000' },
          { id: 113, name: 'Devremülk', count: '50.000' }
        ]
      },
      {
        id: 12, name: 'Kiralık', count: '395.320',
        subCategories: [
          { id: 121, name: 'Ev / Daire', count: '350.000' },
          { id: 122, name: 'İş Yeri', count: '45.320' }
        ]
      }
    ]
  },
  { 
    id: 2, name: 'Vasıta', icon: Car, count: '854.112',
    subCategories: [
      {
        id: 21, name: 'Sıfır Araç', count: '54.112',
        subCategories: [
          { id: 211, name: 'Otomobil', count: '40.000' },
          { id: 212, name: 'Motosiklet', count: '14.112' }
        ]
      },
      {
        id: 22, name: '2. El Araç', count: '800.000',
        subCategories: [
          { id: 221, name: 'Otomobil', count: '600.000' },
          { id: 222, name: 'Arazi, SUV & Pick-up', count: '150.000' },
          { id: 223, name: 'Motosiklet', count: '50.000' }
        ]
      }
    ]
  },
  { id: 3, name: 'Elektronik', icon: Laptop, count: '3.412.005' },
];

const SHOWCASE_ITEMS = [
  { id: 1, title: 'Sahibinden Boyasız Tramersiz 2020 Passat', price: '1.450.000 TL', location: 'İstanbul, Kadıköy', imgSeed: 'car1', badge: { text: 'Satıldı', color: 'bg-red-600' } },
  { id: 2, title: 'Kadıköy Moda\'da Full Eşyalı 3+1 Kiralık Daire', price: '45.000 TL', location: 'İstanbul, Kadıköy', imgSeed: 'house1', badge: null },
  { id: 3, title: 'Kutusu açılmamış iPhone 15 Pro Max 256GB', price: '72.500 TL', location: 'Ankara, Çankaya', imgSeed: 'phone1', badge: { text: 'Fiyatı Düştü', color: 'bg-green-600' } },
  { id: 4, title: 'Acil Satılık Temiz Aile Aracı Egea', price: '780.000 TL', location: 'İzmir, Bornova', imgSeed: 'car2', badge: null },
  { id: 5, title: 'Marmaris\'te Denize Sıfır Yazlık Villa', price: '12.500.000 TL', location: 'Muğla, Marmaris', imgSeed: 'villa', badge: { text: 'Fırsatı Kaçırma', color: 'bg-orange-500' } },
  { id: 6, title: 'Sıfır Ayarında Oyuncu Bilgisayarı RTX 4070', price: '42.000 TL', location: 'Bursa, Nilüfer', imgSeed: 'pc', badge: null },
  { id: 7, title: 'Sahibinden Az Kullanılmış Çamaşır Makinesi', price: '4.500 TL', location: 'Antalya, Muratpaşa', imgSeed: 'machine', badge: null },
  { id: 8, title: '2023 Model Yamaha XMAX 250', price: '240.000 TL', location: 'İstanbul, Beşiktaş', imgSeed: 'motor', badge: { text: 'Satıldı', color: 'bg-red-600' } },
  { id: 9, title: 'Antika El Dokuması Isparta Halısı', price: '15.000 TL', location: 'Isparta, Merkez', imgSeed: 'carpet', badge: { text: 'Acil Satılık', color: 'bg-purple-600' } },
  { id: 10, title: 'Öğrenciden Satılık Temiz Çalışma Masası', price: '800 TL', location: 'Eskişehir, Tepebaşı', imgSeed: 'desk', badge: null },
  { id: 11, title: 'Acil İhtiyaçtan Satılık Tarla 5 Dönüm', price: '2.100.000 TL', location: 'Tekirdağ, Çorlu', imgSeed: 'field', badge: null },
  { id: 12, title: 'Sony A7III Fotoğraf Makinesi + Lens', price: '55.000 TL', location: 'İstanbul, Şişli', imgSeed: 'camera', badge: { text: 'Fiyatı Düştü', color: 'bg-green-600' } },
];

const NEW_LISTINGS = [
  { id: 101, imgSeed: 'car3', title: '2018 Ford Focus Titanium Dizel Otomatik', category: 'Vasıta', price: '950.000 TL', date: 'Bugün 12:45', location: 'Ankara, Yenimahalle' },
  { id: 102, imgSeed: 'laptop1', title: 'MacBook Pro M2 İşlemci 16GB RAM 512SSD', category: 'Elektronik', price: '48.000 TL', date: 'Bugün 11:20', location: 'İzmir, Karşıyaka' },
  { id: 103, imgSeed: 'house2', title: 'Sahibinden 2+1 Masrafsız Merkezde Daire', category: 'Gayrimenkul', price: '2.800.000 TL', date: 'Bugün 09:15', location: 'Bursa, Osmangazi' },
  { id: 104, imgSeed: 'motor2', title: 'Honda Dio Temiz Bakımlı İlk Sahibinden', category: 'Vasıta', price: '85.000 TL', date: 'Dün', location: 'Antalya, Konyaaltı' },
  { id: 105, imgSeed: 'watch', title: 'Apple Watch Series 8 45mm Çiziksiz', category: 'Elektronik', price: '11.500 TL', date: 'Dün', location: 'İstanbul, Üsküdar' },
];

// --- YARDIMCI BİLEŞEN: Katlanabilir (Accordion) Kategori Menüsü ---
const CategoryItem = ({ cat, level = 0 }) => {
  const [isOpen, setIsOpen] = useState(false);
  const hasChildren = cat.subCategories && cat.subCategories.length > 0;
  const Icon = cat.icon;

  return (
    <li className={`${level === 0 ? 'border-b border-gray-100' : ''}`}>
      <div 
        onClick={() => hasChildren && setIsOpen(!isOpen)}
        style={{ paddingLeft: `${level * 16 + 12}px`, paddingRight: '12px' }}
        className={`group flex flex-col justify-center py-2.5 hover:bg-purple-50 transition-colors ${hasChildren ? 'cursor-pointer' : ''}`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {Icon && <Icon size={level === 0 ? 16 : 14} className={`${level === 0 ? 'text-purple-500' : 'text-gray-400'} group-hover:text-purple-700 transition-colors`} />}
            <span className={`font-medium text-gray-700 group-hover:text-purple-800 ${level === 0 ? 'text-[13px]' : 'text-[11px]'}`}>{cat.name}</span>
          </div>
          <div className="flex items-center gap-2">
            {cat.count && level > 0 && <span className="text-[9px] text-gray-400">{cat.count}</span>}
            {hasChildren && <ChevronRight size={14} className={`text-gray-400 group-hover:text-purple-500 transition-transform duration-200 ${isOpen ? 'rotate-90' : ''}`} />}
          </div>
        </div>
        {cat.count && level === 0 && (
          <div className="text-[10px] text-gray-400 pl-6 mt-0.5 hidden lg:block">
            {cat.count} ilan
          </div>
        )}
      </div>
      
      {hasChildren && isOpen && (
        <ul className="bg-gray-50/50 flex flex-col">
          {cat.subCategories.map(subCat => (
            <CategoryItem key={subCat.id} cat={subCat} level={level + 1} />
          ))}
        </ul>
      )}
    </li>
  );
};

export default function HomePage() {
  const navigate = useNavigate();
  const loc = useTurkiyeLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [viewMode, setViewMode] = useState('grid');
  const [selectedItem, setSelectedItem] = useState(null);
  const [activeImageIndex, setActiveImageIndex] = useState(0); // Popup galerisi için state

  // Animasyon State'i
  const [progressState, setProgressState] = useState(false);

  // --- Filtre State'leri (İl/İlçe artık useTurkiyeLocation'dan geliyor; Mahalle çoklu seçim panel state'i) ---
  const [isMahalleOpen, setIsMahalleOpen] = useState(false);
  const mahalleRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (mahalleRef.current && !mahalleRef.current.contains(event.target)) {
        setIsMahalleOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const initialTimer = setTimeout(() => setProgressState(true), 100);
    const interval = setInterval(() => {
      setProgressState(false);
      setTimeout(() => setProgressState(true), 100);
    }, 5000);
    return () => { clearTimeout(initialTimer); clearInterval(interval); };
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-800 flex flex-col">
      
      {/* Özel Animasyonlar için Style Bloğu */}
      <style>{`
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>

      <Header
        showCategoryMenuToggle
        isMobileMenuOpen={isMobileMenuOpen}
        onMobileMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        onLogoClick={() => setSelectedItem(null)}
      />

      {/* ANA İÇERİK - HOME VİEW */}
      <div className="flex flex-col flex-1 w-full">
        
        <main className="max-w-[1200px] mx-auto w-full px-4 py-6 flex flex-col md:flex-row gap-6 flex-1">
          
          {/* SOL MENÜ */}
          <aside className={`${isMobileMenuOpen ? 'block' : 'hidden'} md:block w-full md:w-64 flex-shrink-0 bg-white border border-gray-200 rounded-sm shadow-sm overflow-hidden h-max`}>
            <div className="bg-gray-100 p-3 border-b border-gray-200">
              <h2 className="font-bold text-gray-700 text-sm">Kategoriler</h2>
            </div>
            <ul className="flex flex-col">
              {CATEGORIES.map((cat) => (
                <CategoryItem key={cat.id} cat={cat} />
              ))}
            </ul>

            <div className="p-4 mt-2">
              <div className="bg-gradient-to-br from-orange-50 to-red-50 border border-orange-200 rounded-lg shadow-sm overflow-hidden">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 p-2.5 flex justify-between items-center">
                  <h2 className="font-bold text-white text-xs flex items-center gap-2">
                    <Star size={14} className="fill-current" /> Günün Fırsatı
                  </h2>
                </div>
                <div className="p-3 cursor-pointer hover:bg-orange-100/50 transition-colors">
                  <div className="w-full h-28 bg-gray-200 rounded mb-3 overflow-hidden relative">
                     <img src="https://picsum.photos/seed/deal/200/150" alt="Günün Fırsatı" className="w-full h-full object-cover" />
                     <div className="absolute top-0 right-0 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-bl">ACİL</div>
                  </div>
                  <h3 className="text-xs font-semibold text-gray-800 line-clamp-2">Sahibinden Acil İhtiyaçtan Kelepir 2+1 Merkezde Daire</h3>
                  <p className="text-red-600 font-extrabold text-sm mt-1">1.150.000 TL</p>
                </div>
              </div>
            </div>
          </aside>

          {/* SAĞ İÇERİK */}
          <section className="flex-1 w-full overflow-hidden">
            
            {/* ÜST İSTATİSTİKLER VE HIZLI AKSİYONLAR */}
            <div className="mb-6 flex flex-wrap lg:flex-nowrap items-center justify-between gap-4 w-full">
              
              {/* Sol Taraf: Dairesel İstatistikler */}
              <div className="flex flex-wrap items-center justify-start gap-4 lg:gap-6">
                {/* Stat 1: Aktif İlan */}
                <div className="flex items-center gap-2">
                  <div className="relative w-10 h-10">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                      <path className="text-gray-100 stroke-current" strokeWidth="3" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      <path className="text-indigo-500 stroke-current transition-all duration-[1500ms] ease-out" strokeWidth="3" strokeDasharray={progressState ? "85, 100" : "0, 100"} fill="none" strokeLinecap="round" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center font-bold text-[10px] text-indigo-700">1.2M</div>
                  </div>
                  <div className="text-[10px] font-bold text-gray-500 uppercase leading-[1.1]">Aktif<br/>İlan</div>
                </div>

                {/* Stat 2: Uzman Sayısı */}
                <div className="flex items-center gap-2">
                  <div className="relative w-10 h-10">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                      <path className="text-gray-100 stroke-current" strokeWidth="3" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      <path className="text-purple-500 stroke-current transition-all duration-[1500ms] ease-out" strokeWidth="3" strokeDasharray={progressState ? "65, 100" : "0, 100"} fill="none" strokeLinecap="round" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center font-bold text-[10px] text-purple-700">4.5K</div>
                  </div>
                  <div className="text-[10px] font-bold text-gray-500 uppercase leading-[1.1]">Kayıtlı<br/>Uzman</div>
                </div>

                {/* Stat 3: Çözüm Süresi */}
                <div className="flex items-center gap-2">
                  <div className="relative w-10 h-10">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                      <path className="text-gray-100 stroke-current" strokeWidth="3" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      <path className="text-green-500 stroke-current transition-all duration-[1500ms] ease-out" strokeWidth="3" strokeDasharray={progressState ? "90, 100" : "0, 100"} fill="none" strokeLinecap="round" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center font-bold text-[10px] text-green-700">24s</div>
                  </div>
                  <div className="text-[10px] font-bold text-gray-500 uppercase leading-[1.1]">Çözüm<br/>Süresi</div>
                </div>

                {/* Stat 4: Başarı Yüzdesi */}
                <div className="flex items-center gap-2">
                  <div className="relative w-10 h-10">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                      <path className="text-gray-100 stroke-current" strokeWidth="3" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                      <path className="text-orange-500 stroke-current transition-all duration-[1500ms] ease-out" strokeWidth="3" strokeDasharray={progressState ? "98, 100" : "0, 100"} fill="none" strokeLinecap="round" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center font-bold text-[10px] text-orange-700">%98</div>
                  </div>
                  <div className="text-[10px] font-bold text-gray-500 uppercase leading-[1.1]">Memnuniyet<br/>Oranı</div>
                </div>
              </div>

              {/* Sağ Taraf: Aksiyon Butonları */}
              <div className="flex items-center gap-2 shrink-0 ml-auto mt-2 lg:mt-0">
                <button className="bg-gradient-to-br from-indigo-500 to-indigo-700 hover:from-indigo-600 hover:to-indigo-800 text-white shadow-sm hover:shadow transition-all rounded px-4 py-2 flex items-center justify-center gap-2 transform hover:-translate-y-0.5">
                  <Search size={16} className="text-indigo-100" />
                  <span className="text-sm font-bold">Almak İstiyorum</span>
                </button>

                <button onClick={() => navigate("/register")} className="bg-gradient-to-br from-purple-500 to-fuchsia-600 hover:from-purple-600 hover:to-fuchsia-700 text-white shadow-sm hover:shadow transition-all rounded px-4 py-2 flex items-center justify-center gap-2 transform hover:-translate-y-0.5">
                  <Tag size={16} className="text-purple-100" />
                  <span className="text-sm font-bold">Satmak İstiyorum</span>
                </button>
              </div>
            </div>

            {/* FİLTRE & ARAMA (Küçültülmüş Kompakt Tasarım) */}
            <div className="bg-white border border-gray-200 rounded-sm shadow-sm p-3 mb-6">
              <div className="flex flex-col lg:flex-row gap-3 items-end justify-between">
                
                <div className="flex-1 w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                  <div className="flex flex-col">
                    <label className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-0.5">Kategori</label>
                    <select className="w-full p-1.5 border border-gray-200 rounded text-[11px] outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 bg-gray-50 hover:bg-white transition-colors cursor-pointer text-gray-700 h-[28px]">
                      <option value="">Tüm Kategoriler</option>
                      <option value="gayrimenkul">Gayrimenkul</option>
                      <option value="vasita">Vasıta</option>
                      <option value="elektronik">Elektronik</option>
                    </select>
                  </div>
                  <div className="flex flex-col">
                    <label className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-0.5">İl</label>
                    <select
                      value={loc.selectedProvince?.id || ""}
                      onChange={e => {
                        const p = loc.provinces.find(p => p.id === Number(e.target.value));
                        loc.setSelectedProvince(p || null);
                      }}
                      className="w-full p-1.5 border border-gray-200 rounded text-[11px] outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 bg-gray-50 hover:bg-white transition-colors cursor-pointer text-gray-700 h-[28px]">
                      <option value="">{loc.loadingProv ? "Yükleniyor..." : "Tüm İller"}</option>
                      {loc.provinces.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                  <div className="flex flex-col">
                    <label className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-0.5">İlçe</label>
                    <select
                      value={loc.selectedDistrict?.id || ""}
                      disabled={!loc.selectedProvince}
                      onChange={e => {
                        const d = loc.districts.find(d => d.id === Number(e.target.value));
                        loc.setSelectedDistrict(d || null);
                      }}
                      className="w-full p-1.5 border border-gray-200 rounded text-[11px] outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 bg-gray-50 hover:bg-white transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed text-gray-700 h-[28px]">
                      <option value="">{loc.loadingDist ? "Yükleniyor..." : "Tüm İlçeler"}</option>
                      {loc.districts.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                    </select>
                  </div>

                  {/* MAHALLE — çoklu seçim, gerçek API verisiyle */}
                  <div className="flex flex-col relative" ref={mahalleRef}>
                    <label className="text-[9px] font-bold text-gray-500 uppercase tracking-wider mb-0.5">Mahalle</label>
                    <div
                      onClick={() => loc.selectedDistrict && setIsMahalleOpen(!isMahalleOpen)}
                      className={`w-full px-2 py-1.5 border border-gray-200 rounded text-[11px] outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 bg-gray-50 hover:bg-white transition-colors text-gray-700 flex justify-between items-center h-[28px] select-none ${
                        loc.selectedDistrict ? "cursor-pointer" : "cursor-not-allowed opacity-40"
                      }`}
                    >
                      <span className="truncate pr-2 font-medium">
                        {loc.loadingNeigh ? "Yükleniyor..." :
                         loc.selectedNeighborhoods.length === 0 ? "Tüm Mahalleler" :
                         loc.selectedNeighborhoods.length === 1 ? loc.selectedNeighborhoods[0].name :
                         `${loc.selectedNeighborhoods.length} Mahalle Seçili`}
                      </span>
                      <ChevronDown size={12} className={`text-gray-400 transition-transform ${isMahalleOpen ? 'rotate-180' : ''}`} />
                    </div>

                    {isMahalleOpen && loc.selectedDistrict && (
                      <div className="absolute top-[calc(100%+2px)] left-0 w-full bg-white border border-gray-200 rounded-md shadow-xl z-[60] max-h-48 overflow-y-auto">
                         {loc.neighborhoods.length === 0 ? (
                           <div className="px-2.5 py-3 text-[11px] text-gray-400 text-center">Mahalle bulunamadı.</div>
                         ) : loc.neighborhoods.map(n => (
                           <label key={n.id} className="flex items-center gap-2.5 px-2.5 py-2 hover:bg-purple-50 cursor-pointer text-[11px] text-gray-700 border-b border-gray-50 last:border-0 transition-colors">
                             <input
                               type="checkbox"
                               className="rounded-sm border-gray-300 w-3.5 h-3.5 cursor-pointer accent-purple-600"
                               checked={loc.selectedNeighborhoods.some(x => x.id === n.id)}
                               onChange={() => loc.toggleNeighborhood(n)}
                             />
                             <span className="truncate">{n.name}</span>
                           </label>
                         ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex w-full lg:w-auto items-center justify-between lg:justify-end gap-2 mt-2 lg:mt-0">
                  <button className="flex-1 lg:flex-none flex items-center justify-center gap-1.5 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-800 hover:to-indigo-700 text-white px-4 py-1.5 rounded text-[11px] font-bold transition-all shadow-sm">
                    <Filter size={14} /> Filtrele
                  </button>
                  
                  <div className="flex items-center border border-gray-200 rounded bg-gray-50 overflow-hidden h-[28px] flex-shrink-0 shadow-sm">
                    <button 
                      onClick={() => setViewMode('grid')}
                      className={`px-2 py-1 transition-all flex items-center justify-center ${viewMode === 'grid' ? 'bg-purple-100 text-purple-700 shadow-inner' : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'}`}
                    >
                      <LayoutGrid size={14} />
                    </button>
                    <div className="w-px h-full bg-gray-200"></div>
                    <button 
                      onClick={() => setViewMode('list')}
                      className={`px-2 py-1 transition-all flex items-center justify-center ${viewMode === 'list' ? 'bg-purple-100 text-purple-700 shadow-inner' : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'}`}
                    >
                      <List size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* VİTRİN */}
            <div className="flex items-center justify-between mb-4 pb-2 border-b-2 border-gray-200">
              <h1 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                Anasayfa Vitrini
                <span className="bg-purple-100 text-purple-800 text-xs px-2 py-0.5 rounded-full font-semibold">Öne Çıkanlar</span>
              </h1>
              <a href="#" className="text-sm text-purple-600 hover:underline font-medium">Tümünü Gör</a>
            </div>

            <div className={viewMode === 'grid' ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3" : "flex flex-col gap-3"}>
              {SHOWCASE_ITEMS.map((item) => (
                <div 
                  key={item.id} 
                  onClick={() => { setSelectedItem(item); setActiveImageIndex(0); }}
                  className={`bg-white border border-gray-200 hover:border-purple-400 hover:shadow-lg transition-all rounded-sm overflow-hidden flex group cursor-pointer relative ${viewMode === 'grid' ? 'flex-col' : 'flex-col sm:flex-row'}`}
                >
                  {/* Dinamik Şerit Etiket - Sol Üst */}
                  {item.badge && (
                    <div className={`absolute w-36 ${item.badge.color} text-white text-[10px] font-bold text-center py-1.5 -rotate-45 z-20 shadow-md uppercase tracking-wider top-4 -left-10`}>
                      {item.badge.text}
                    </div>
                  )}
                  <button 
                    onClick={(e) => e.stopPropagation()} 
                    className="absolute top-2 right-2 p-1.5 bg-white/70 hover:bg-white rounded-full z-10 text-gray-400 hover:text-red-500 transition-colors shadow-sm"
                  >
                    <Heart size={16} />
                  </button>

                  <div className={`bg-gray-100 relative overflow-hidden flex-shrink-0 ${viewMode === 'grid' ? 'w-full h-32' : 'w-full sm:w-56 h-40 sm:h-32'}`}>
                    <img src={`https://picsum.photos/seed/${item.imgSeed}/400/300`} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute bottom-1 right-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded z-10">1/5</div>
                  </div>

                  <div className={`p-3 flex flex-1 ${viewMode === 'grid' ? 'flex-col' : 'flex-col sm:flex-row sm:items-center'}`}>
                    <div className={`${viewMode === 'grid' ? '' : 'flex-1 pr-4'}`}>
                      <h3 className={`text-[13px] text-gray-700 font-medium leading-snug mb-2 group-hover:text-purple-700 transition-colors ${viewMode === 'grid' ? 'line-clamp-2' : 'line-clamp-2 sm:text-[15px] sm:font-semibold'}`}>
                        {item.title}
                      </h3>
                      {viewMode === 'list' && (
                        <div className="hidden sm:flex items-center text-[11px] text-gray-500 gap-2 mb-2">
                          <span className="bg-gray-50 px-2 py-1 rounded border border-gray-100">Krediye Uygun</span>
                          <span className="bg-gray-50 px-2 py-1 rounded border border-gray-100">Ekspertizli</span>
                        </div>
                      )}
                    </div>
                    
                    <div className={`${viewMode === 'grid' ? 'mt-auto' : 'sm:text-right mt-2 sm:mt-0 flex flex-row sm:flex-col justify-between items-center sm:items-end'}`}>
                      <p className={`text-purple-700 font-bold ${viewMode === 'grid' ? 'text-[15px] mb-1' : 'text-lg sm:mb-2'}`}>{item.price}</p>
                      <div className={`flex items-center text-gray-500 gap-1 border-gray-100 ${viewMode === 'grid' ? 'text-[11px] mt-1 border-t pt-2' : 'text-xs'}`}>
                        <MapPin size={10} className="text-purple-400" />
                        <span className="truncate">{item.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* YENİ İLANLAR */}
            <div className="mt-10">
              <div className="flex items-center justify-between mb-4 pb-2 border-b-2 border-gray-200">
                <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                  Yeni Eklenen İlanlar
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full font-semibold">Taze Taze</span>
                </h2>
                <a href="#" className="text-sm text-purple-600 hover:underline font-medium">Tüm Listeyi Gör</a>
              </div>
              
              <ul className="flex flex-col">
                {NEW_LISTINGS.map((listing) => (
                  <li key={listing.id} onClick={() => { setSelectedItem(listing); setActiveImageIndex(0); }} className="bg-white border border-gray-200 rounded-md shadow-sm mb-[5px] flex flex-col sm:flex-row sm:items-center p-2 hover:bg-purple-50 transition-colors group cursor-pointer gap-3">
                    {/* Görsel */}
                    <div className="w-14 h-10 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                       <img src={`https://picsum.photos/seed/${listing.imgSeed}/100/100`} alt={listing.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                    </div>
                    {/* Başlık ve Kategori */}
                    <div className="flex-1 min-w-0">
                      <h3 className="text-[13px] font-semibold text-gray-800 group-hover:text-purple-700 truncate">{listing.title}</h3>
                      <div className="flex items-center gap-2 mt-0.5 sm:hidden">
                        <span className="bg-gray-100 px-1.5 py-0.5 rounded text-[9px] text-gray-500 font-medium">{listing.category}</span>
                        <span className="text-gray-400 text-[10px] flex items-center"><MapPin size={10} className="mr-0.5"/>{listing.location}</span>
                      </div>
                    </div>
                    {/* Diğer Detaylar */}
                    <div className="hidden sm:block w-20 flex-shrink-0"><span className="bg-gray-100 px-2 py-1 rounded text-[11px] text-gray-500 font-medium">{listing.category}</span></div>
                    <div className="hidden md:flex items-center text-gray-500 text-[11px] w-32 flex-shrink-0 truncate"><MapPin size={12} className="mr-1 flex-shrink-0"/> <span className="truncate">{listing.location}</span></div>
                    <div className="flex items-center justify-between sm:justify-end gap-3 w-full sm:w-auto mt-1 sm:mt-0 border-t sm:border-t-0 border-gray-100 pt-1.5 sm:pt-0">
                       <div className="text-purple-700 font-bold text-[13px] w-auto sm:w-24 text-left sm:text-right">{listing.price}</div>
                       <div className="text-gray-400 text-[11px] w-auto sm:w-16 text-right">{listing.date}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        </main>
      </div>

      {/* İLAN DETAY MODAL (Küçültülmüş ve Gelişmiş Galeri/Detay Eklendi) */}
      {selectedItem && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedItem(null)}></div>
          <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col md:flex-row z-10">
            <button onClick={() => setSelectedItem(null)} className="absolute top-3 right-3 z-20 bg-black/50 text-white hover:bg-red-500 rounded-full p-1.5 transition-colors"><X size={20} /></button>
            
            {/* Sol: Fotoğraf Galerisi */}
            <div className="w-full md:w-[55%] bg-gray-100 flex flex-col h-64 md:h-auto border-r border-gray-200">
              <div className="relative flex-1 bg-black group/slider">
                <img 
                  src={`https://picsum.photos/seed/${selectedItem.imgSeed}${activeImageIndex === 0 ? '' : activeImageIndex}/800/600`} 
                  alt={selectedItem.title} 
                  className="w-full h-full object-contain transition-all duration-300" 
                />
                <button 
                  onClick={(e) => { e.stopPropagation(); setActiveImageIndex(prev => prev === 0 ? 4 : prev - 1); }}
                  className="absolute left-3 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white p-1.5 rounded-full text-black opacity-0 group-hover/slider:opacity-100 transition-all shadow-md"><ChevronLeft size={20}/></button>
                <button 
                  onClick={(e) => { e.stopPropagation(); setActiveImageIndex(prev => prev === 4 ? 0 : prev + 1); }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white p-1.5 rounded-full text-black opacity-0 group-hover/slider:opacity-100 transition-all shadow-md"><ChevronRight size={20}/></button>
              </div>
              <div className="flex gap-2 p-3 overflow-x-auto bg-gray-200 hide-scrollbar justify-center">
                {[0, 1, 2, 3, 4].map(i => (
                  <img 
                    key={i} 
                    onClick={() => setActiveImageIndex(i)}
                    src={`https://picsum.photos/seed/${selectedItem.imgSeed}${i === 0 ? '' : i}/100/100`} 
                    className={`w-14 h-14 object-cover rounded cursor-pointer border-2 transition-all duration-200 ${activeImageIndex === i ? 'border-purple-600 scale-105' : 'border-transparent hover:border-gray-400 opacity-70 hover:opacity-100'}`} 
                    alt={`thumbnail-${i}`} 
                  />
                ))}
              </div>
            </div>
            
            {/* Sağ: İlan Detayları */}
            <div className="w-full md:w-[45%] flex flex-col bg-white overflow-y-auto">
              <div className="p-5 flex-1">
                <div className="flex justify-between items-start mb-2">
                   <span className="bg-purple-100 text-purple-700 text-[10px] px-2 py-1 rounded-full font-bold uppercase tracking-wider">{selectedItem.category || 'ÖNE ÇIKAN'}</span>
                   <div className="flex items-center gap-3 text-gray-400"><Heart size={18} className="cursor-pointer hover:text-red-500 transition-colors" /></div>
                </div>
                <h2 className="text-xl font-bold text-gray-800 leading-tight mb-2">{selectedItem.title}</h2>
                <div className="flex items-center justify-between text-gray-500 text-xs mb-4 pb-3 border-b border-gray-100">
                  <span className="flex items-center gap-1"><MapPin size={12} className="text-purple-500"/>{selectedItem.location}</span>
                  <span className="text-gray-400">İlan No: <strong className="text-gray-600">{100000000 + selectedItem.id}</strong></span>
                </div>
                
                <p className="text-3xl font-extrabold text-purple-700 mb-2">{selectedItem.price}</p>
                
                {/* İstatistikler */}
                <div className="flex gap-4 text-[11px] text-gray-500 mb-5 bg-purple-50/50 p-2 rounded-lg border border-purple-100">
                  <div className="flex items-center gap-1"><Heart size={12} className="text-red-400"/> <strong className="text-gray-700">124</strong> favori</div>
                  <div className="flex items-center gap-1"><User size={12} className="text-blue-400"/> <strong className="text-gray-700">38</strong> kişi inceliyor</div>
                </div>

                <div className="space-y-2.5 text-xs mb-6 text-gray-600">
                  <div className="flex justify-between border-b border-gray-50 pb-1"><span className="text-gray-400">Durum</span><span className="font-semibold text-green-600">İkinci El</span></div>
                  <div className="flex justify-between border-b border-gray-50 pb-1"><span className="text-gray-400">Kimden</span><span className="font-semibold text-gray-800">Sahibinden</span></div>
                  <div className="flex justify-between border-b border-gray-50 pb-1"><span className="text-gray-400">İlan Tarihi</span><span className="font-semibold text-gray-800">Bugün</span></div>
                </div>

                {/* Teklif / İndirim Talebi */}
                <div className="mb-6">
                  <h4 className="text-[11px] font-bold text-gray-500 uppercase mb-2">Hızlı İndirim Talep Et</h4>
                  <div className="flex gap-2">
                    <button className="flex-1 bg-white border border-gray-200 hover:border-purple-400 hover:bg-purple-50 hover:text-purple-700 text-gray-700 py-1.5 rounded text-xs font-semibold transition-all">%10 İndirim</button>
                    <button className="flex-1 bg-white border border-gray-200 hover:border-purple-400 hover:bg-purple-50 hover:text-purple-700 text-gray-700 py-1.5 rounded text-xs font-semibold transition-all">%20 İndirim</button>
                    <button className="flex-1 bg-white border border-purple-200 hover:bg-purple-600 hover:text-white text-purple-700 py-1.5 rounded text-xs font-semibold transition-all">Özel Teklif</button>
                  </div>
                </div>

                {/* Satıcı Profili */}
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-3">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-bold text-sm shadow-inner">AO</div>
                    <div>
                      <h4 className="font-bold text-gray-800 text-sm">Ahmet Otomotiv</h4>
                      <p className="text-[10px] text-green-600 flex items-center gap-1 mt-0.5"><ShieldCheck size={12} /> Kurumsal Üye • Kimlik Onaylı</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="flex-1 bg-white border border-purple-200 hover:border-purple-600 text-purple-700 py-2 rounded-lg font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"><MessageSquare size={14}/> Mesaj At</button>
                    <button className="flex-1 bg-indigo-50 border border-indigo-200 hover:border-indigo-600 text-indigo-700 py-2 rounded-lg font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"><Phone size={14}/> Telefon</button>
                  </div>
                </div>
              </div>
              <div className="p-4 border-t border-gray-100 bg-gray-50 shrink-0">
                 <button className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white py-3.5 rounded-xl font-bold text-base shadow-[0_5px_15px_rgba(99,102,241,0.3)] hover:shadow-[0_8px_20px_rgba(99,102,241,0.4)] transform hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2">
                  <Star size={18} className="fill-current"/> Hemen Al / Teklif Ver
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-gray-900 text-gray-300 mt-12 py-10 text-sm border-t-4 border-purple-600 w-full">
        <div className="max-w-[1200px] mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div><h4 className="text-white font-bold mb-4 uppercase text-xs tracking-wider">Kurumsal</h4><ul className="space-y-2"><li><a href="#" className="hover:text-purple-400 transition-colors">Hakkımızda</a></li><li><a href="#" className="hover:text-purple-400 transition-colors">Müşteri Hizmetleri</a></li></ul></div>
          <div><h4 className="text-white font-bold mb-4 uppercase text-xs tracking-wider">Hizmetlerimiz</h4><ul className="space-y-2"><li><a href="#" className="hover:text-purple-400 transition-colors">Güvenli e-Ticaret (GeT)</a></li><li><a href="#" className="hover:text-purple-400 transition-colors">Ekspertiz Hizmetleri</a></li></ul></div>
          <div><h4 className="text-white font-bold mb-4 uppercase text-xs tracking-wider">Mağazalar</h4><ul className="space-y-2"><li><a href="#" className="hover:text-purple-400 transition-colors">Mağaza Açmak İstiyorum</a></li><li><a href="#" className="hover:text-purple-400 transition-colors">Mağaza Fiyatları</a></li></ul></div>
          <div>
            <h4 className="text-white font-bold mb-4 uppercase text-xs tracking-wider">Bizi Takip Edin</h4>
            <div className="flex gap-4 mb-4">
              <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-purple-600 hover:text-white transition-colors">FB</a>
              <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-purple-600 hover:text-white transition-colors">IG</a>
            </div>
            <p className="text-xs text-gray-500">Müşteri Hizmetleri<br/><span className="text-lg text-white font-bold">0850 XXX XX XX</span></p>
          </div>
        </div>
        <div className="max-w-[1200px] mx-auto px-4 mt-8 pt-8 border-t border-gray-800 text-xs text-center text-gray-500">Copyright © 2026 TeklifMeydanı. Tüm hakları saklıdır.</div>
      </footer>
    </div>
  );
}