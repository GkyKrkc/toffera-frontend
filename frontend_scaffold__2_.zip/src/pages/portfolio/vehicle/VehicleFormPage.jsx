import { useState, useEffect } from "react"
import { useNavigate, useParams, Link } from "react-router-dom"
import {
    Car, ChevronRight, Save, ArrowLeft, ChevronDown, Loader2, Image, ImagePlus, FileText
} from "lucide-react"
import Header from "@/components/layout/Header"
import { useAuth } from "@/store/AuthContext"
import { useToast } from "@/components/ui/Toast"
import api from "@/lib/axios"
import CAR_DATA from "@/data/carData"
import { YAKIT_OPTIONS, VITES_OPTIONS, RENK_OPTIONS, KM_OPTIONS, YIL_OPTIONS } from "@/data/vehicleData"
import { useTurkiyeLocation } from "@/hooks/useTurkiyeLocation"
import ImageUploadModal from "@/components/portfolio/ImageUploadModal"
import DocumentUploadModal from "@/components/portfolio/DocumentUploadModal"
import VehicleDamageSchema from "@/components/portfolio/VehicleDamageSchema"

const STATUS_OPTIONS = [
    { value: "available", label: "Satışta" },
    { value: "reserved",  label: "Rezerve" },
    { value: "sold",      label: "Satıldı" },
]

// 81 il plaka kodu — plaka girilince il otomatik seçilsin diye.
const PLAKA_IL = {1:"Adana",2:"Adıyaman",3:"Afyonkarahisar",4:"Ağrı",5:"Amasya",6:"Ankara",7:"Antalya",8:"Artvin",9:"Aydın",10:"Balıkesir",11:"Bilecik",12:"Bingöl",13:"Bitlis",14:"Bolu",15:"Burdur",16:"Bursa",17:"Çanakkale",18:"Çankırı",19:"Çorum",20:"Denizli",21:"Diyarbakır",22:"Edirne",23:"Elazığ",24:"Erzincan",25:"Erzurum",26:"Eskişehir",27:"Gaziantep",28:"Giresun",29:"Gümüşhane",30:"Hakkari",31:"Hatay",32:"Isparta",33:"Mersin",34:"İstanbul",35:"İzmir",36:"Kars",37:"Kastamonu",38:"Kayseri",39:"Kırklareli",40:"Kırşehir",41:"Kocaeli",42:"Konya",43:"Kütahya",44:"Malatya",45:"Manisa",46:"Kahramanmaraş",47:"Mardin",48:"Muğla",49:"Muş",50:"Nevşehir",51:"Niğde",52:"Ordu",53:"Rize",54:"Sakarya",55:"Samsun",56:"Siirt",57:"Sinop",58:"Sivas",59:"Tekirdağ",60:"Tokat",61:"Trabzon",62:"Tunceli",63:"Şanlıurfa",64:"Uşak",65:"Van",66:"Yozgat",67:"Zonguldak",68:"Aksaray",69:"Bayburt",70:"Karaman",71:"Kırıkkale",72:"Batman",73:"Şırnak",74:"Bartın",75:"Ardahan",76:"Iğdır",77:"Yalova",78:"Karabük",79:"Kilis",80:"Osmaniye",81:"Düzce"}

function sanitizePrice(val) {
    return String(val).replace(/[^0-9]/g, "")
}

function SelectField({ label, value, onChange, options, required, placeholder = "Seçin..." }) {
    return (
        <div className="flex flex-col gap-1 text-left">
            <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">
                {label} {required && <span className="text-red-500">*</span>}
            </label>
            <div className="relative">
                <select value={value || ""} onChange={e => onChange(e.target.value)}
                        className="w-full appearance-none px-3 py-2.5 bg-gray-50 hover:bg-white border border-gray-200 hover:border-gray-300 focus:border-purple-400 focus:bg-white focus:ring-1 focus:ring-purple-400 text-xs font-medium text-gray-700 rounded outline-none cursor-pointer transition-all">
                    <option value="">{placeholder}</option>
                    {options.map(o => (
                        <option key={typeof o === "string" ? o : o.value} value={typeof o === "string" ? o : o.value}>
                            {typeof o === "string" ? o : o.label}
                        </option>
                    ))}
                </select>
                <ChevronDown size={11} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
        </div>
    )
}

export default function VehicleFormPage() {
    const { id } = useParams()
    const navigate = useNavigate()
    const toast = useToast()
    const { isAuthenticated, loading: authLoading } = useAuth()
    const isEdit = !!id

    const loc = useTurkiyeLocation()
    const [saving, setSaving] = useState(false)
    const [loadingItem, setLoadingItem] = useState(isEdit)

    const [selBrand, setSelBrand] = useState("")
    const [selModel, setSelModel] = useState("")
    const [selVersion, setSelVersion] = useState("")

    const carModels = CAR_DATA.find(b => b.marka === selBrand)?.modeller || []
    const carVersions = carModels.find(m => m.ad === selModel)?.versiyonlar || []

    const [form, setForm] = useState({
        title: "", description: "", price: "", status: "available", district: "", features: {},
    })
    const [images, setImages] = useState([])
    const [documents, setDocuments] = useState([])
    const [showGallery, setShowGallery] = useState(false)
    const [showDocs, setShowDocs] = useState(false)
    const [moderationStatus, setModerationStatus] = useState(null)
    const [moderationNote, setModerationNote] = useState(null)
    const [ownershipVerifiedAt, setOwnershipVerifiedAt] = useState(null)

    const getImageUrl = (img) => img?.url || img?.path || img?.full_url || img
    const setFeature = (key, val) => setForm(f => ({ ...f, features: { ...f.features, [key]: val } }))

    useEffect(() => {
        if (authLoading) return
        if (!isAuthenticated) { navigate("/"); return }
        if (!isEdit) return
        api.get(`/agent/portfolio/${id}`)
            .then(res => {
                const item = res.data.data || res.data
                setForm({
                    title: item.title || "", description: item.description || "", price: item.price || "",
                    status: item.status || "available", district: item.district || "", features: item.features || {},
                })
                setImages(item.images || [])
                setDocuments(item.documents || [])
                setModerationStatus(item.moderation_status || null)
                setModerationNote(item.moderation_note || null)
                setOwnershipVerifiedAt(item.ownership_verified_at || null)
                if (item.features?.marka) {
                    setSelBrand(item.features.marka)
                    if (item.features.model) setSelModel(item.features.model)
                    if (item.features.versiyon) setSelVersion(item.features.versiyon)
                }
                if (item.features?.il) {
                    const tryRestore = (attempt = 0) => {
                        const provList = loc.provinces
                        if (provList.length === 0 && attempt < 20) { setTimeout(() => tryRestore(attempt + 1), 200); return }
                        const p = provList.find(p => p.name === item.features.il)
                        if (p) {
                            loc.setSelectedProvince(p)
                            if (item.features?.ilce) {
                                setTimeout(() => {
                                    const d = loc.districts.find(d => d.name === item.features.ilce)
                                    if (d) loc.setSelectedDistrict(d)
                                }, 600)
                            }
                        }
                    }
                    setTimeout(tryRestore, 400)
                }
            })
            .catch(() => { toast({ message: "Veri yüklenemedi.", type: "error" }); navigate("/portfolio/vehicle") })
            .finally(() => setLoadingItem(false))
    }, [id, authLoading, isAuthenticated])

    // Otomatik başlık
    useEffect(() => {
        if (selBrand) {
            const parts = [selBrand, selModel, selVersion].filter(Boolean)
            const yil = form.features.yil || ""
            setForm(f => ({ ...f, title: [...parts, yil].filter(Boolean).join(" ") }))
        }
    }, [selBrand, selModel, selVersion, form.features.yil])

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (!selBrand) { toast({ message: "Araç markası zorunludur.", type: "error" }); return }
        setSaving(true)
        try {
            const payload = {
                type: "vasita",
                ...form,
                price: form.price || null,
                district: loc.selectedProvince?.name
                    ? [loc.selectedDistrict?.name, loc.selectedProvince?.name].filter(Boolean).join(", ")
                    : form.district || null,
                features: {
                    ...form.features,
                    marka: selBrand, model: selModel || null, versiyon: selVersion || null,
                    il: loc.selectedProvince?.name || form.features.il || "",
                    ilce: loc.selectedDistrict?.name || form.features.ilce || "",
                    tramer_tutari: form.features.tramer_tutari ? Number(form.features.tramer_tutari) : null,
                },
            }
            if (isEdit) {
                await api.put(`/agent/portfolio/${id}`, payload)
                toast({ message: "Araç güncellendi." })
            } else {
                await api.post("/agent/portfolio", payload)
                toast({ message: "Araç portföye eklendi." })
            }
            navigate("/portfolio/vehicle")
        } catch (err) {
            const code = err?.response?.data?.code
            if (code === "PORTFOLIO_LOCKED_BY_OFFERS") {
                toast({ message: err.response.data.message || "Bu araç için aktif teklifler var, önce onları geri çekmelisiniz.", type: "error" })
            } else {
                toast({ message: err?.response?.data?.message || "Kayıt başarısız.", type: "error" })
            }
        } finally { setSaving(false) }
    }

    if (loadingItem) {
        return (
            <div className="min-h-screen bg-gray-100 flex flex-col">
                <Header />
                <div className="flex items-center justify-center flex-1">
                    <div className="w-6 h-6 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-gray-100 font-sans text-gray-800 flex flex-col">
            <Header />

            <main className="max-w-[1200px] mx-auto w-full px-4 py-6 flex-1">

                <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 mb-6">
                    <Link to="/portfolio" className="hover:text-purple-700 transition-colors">Portföy</Link>
                    <ChevronRight size={10} />
                    <Link to="/portfolio/vehicle" className="hover:text-purple-700 transition-colors">Vasıta</Link>
                    <ChevronRight size={10} />
                    <span className="text-gray-700">{isEdit ? "Düzenle" : "Yeni Araç"}</span>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">

                    <div className="lg:col-span-8 bg-white border border-gray-200 rounded-sm shadow-sm overflow-hidden">
                        <div className="flex items-center gap-3 px-6 py-4 border-b border-gray-200 bg-gray-50">
                            <div className="w-8 h-8 bg-purple-50 rounded flex items-center justify-center text-purple-700">
                                <Car size={15} />
                            </div>
                            <div>
                                <p className="text-[9px] font-bold uppercase tracking-wider text-purple-700">Vasıta Portföyü</p>
                                <h1 className="text-sm font-bold text-gray-800">{isEdit ? "Aracı Düzenle" : "Yeni Araç Ekle"}</h1>
                            </div>
                        </div>

                        <form onSubmit={handleSubmit} className="p-6 space-y-6">

                            {/* Kaskad marka/model */}
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-3 pb-2 border-b border-gray-100">ARAÇ BİLGİLERİ</p>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    <SelectField label="Marka" required
                                                 value={selBrand}
                                                 onChange={v => { setSelBrand(v); setSelModel(""); setSelVersion("") }}
                                                 options={CAR_DATA.map(b => b.marka)}
                                                 placeholder="Marka Seçin" />
                                    <SelectField label="Model"
                                                 value={selModel}
                                                 onChange={v => { setSelModel(v); setSelVersion("") }}
                                                 options={carModels.map(m => m.ad)}
                                                 placeholder={selBrand ? "Model Seçin" : "Önce Marka"} />
                                    <SelectField label="Donanım / Motor"
                                                 value={selVersion}
                                                 onChange={setSelVersion}
                                                 options={carVersions.map(v => ({ value: v.ad, label: `${v.ad} — ${v.yakit}, ${v.vites}` }))}
                                                 placeholder={selModel ? "Donanım Seçin" : "Önce Model"} />
                                </div>
                            </div>

                            {/* Teknik özellikler */}
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-3 pb-2 border-b border-gray-100">TEKNİK ÖZELLİKLER</p>
                                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                    <SelectField label="Model Yılı" value={form.features.yil} onChange={v => setFeature("yil", v)} options={YIL_OPTIONS} />
                                    <SelectField label="KM Durumu" value={form.features.km} onChange={v => setFeature("km", v)} options={KM_OPTIONS} />
                                    <SelectField label="Yakıt Tipi" value={form.features.yakit} onChange={v => setFeature("yakit", v)} options={YAKIT_OPTIONS} />
                                    <SelectField label="Vites" value={form.features.vites} onChange={v => setFeature("vites", v)} options={VITES_OPTIONS} />
                                    <SelectField label="Renk" value={form.features.renk} onChange={v => setFeature("renk", v)} options={RENK_OPTIONS} />
                                    <div className="flex flex-col gap-1 text-left">
                                        <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">Plaka İli</label>
                                        <div className="relative">
                                            <select value={loc.selectedProvince?.id || ""}
                                                    disabled={!loc.provinces?.length}
                                                    onChange={e => { const p = (loc.provinces || []).find(p => p.id === Number(e.target.value)); loc.setSelectedProvince(p || null); loc.setSelectedDistrict(null) }}
                                                    className="w-full appearance-none px-3 py-2.5 bg-gray-50 border border-gray-200 hover:border-gray-300 focus:border-purple-400 focus:bg-white focus:ring-1 focus:ring-purple-400 text-xs font-medium text-gray-700 rounded outline-none cursor-pointer transition-all disabled:opacity-50">
                                                <option value="">{loc.provinces?.length ? "İl Seçin" : "Yükleniyor..."}</option>
                                                {(loc.provinces || []).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                                            </select>
                                            <ChevronDown size={11} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Plaka & Şasi */}
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-3 pb-2 border-b border-gray-100">PLAKA & ŞASİ</p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                    <div className="flex flex-col gap-1 text-left">
                                        <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">
                                            Plaka <span className="text-gray-400 font-normal normal-case">(opsiyonel)</span>
                                        </label>
                                        <input type="text" placeholder="34 ABC 123" maxLength={10}
                                               value={form.features.plaka || ""}
                                               onChange={e => {
                                                   const raw = e.target.value.toUpperCase().replace(/[^A-ZÇĞİÖŞÜ0-9 ]/g, "")
                                                   setFeature("plaka", raw)
                                                   const kod = parseInt(raw.trim().split(/[\s-]/)[0], 10)
                                                   if (kod >= 1 && kod <= 81 && loc.provinces?.length) {
                                                       const ilAdi = PLAKA_IL[kod]
                                                       if (ilAdi) {
                                                           const p = loc.provinces.find(p => p.name.toLowerCase().includes(ilAdi.toLowerCase()) || ilAdi.toLowerCase().includes(p.name.toLowerCase()))
                                                           if (p) { loc.setSelectedProvince(p); loc.setSelectedDistrict(null) }
                                                       }
                                                   }
                                               }}
                                               className="px-3 py-2.5 bg-gray-50 border border-gray-200 hover:border-gray-300 focus:border-purple-400 focus:bg-white focus:ring-1 focus:ring-purple-400 text-xs font-bold text-gray-800 tracking-widest rounded outline-none transition-all placeholder:text-gray-400 placeholder:font-normal placeholder:tracking-normal uppercase" />
                                        <p className="text-[9px] text-gray-400">
                                            Örn: 34 ABC 123 — il otomatik seçilir
                                            {loc.selectedProvince && form.features.plaka && (
                                                <span className="ml-1 text-purple-700 font-bold">→ {loc.selectedProvince.name}</span>
                                            )}
                                        </p>
                                    </div>
                                    <div className="flex flex-col gap-1 text-left">
                                        <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">
                                            Şasi Numarası <span className="text-gray-400 font-normal normal-case">(opsiyonel)</span>
                                        </label>
                                        <input type="text" placeholder="WBA12345678901234" maxLength={17}
                                               value={form.features.sasi_no || ""}
                                               onChange={e => setFeature("sasi_no", e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))}
                                               className="px-3 py-2.5 bg-gray-50 border border-gray-200 hover:border-gray-300 focus:border-purple-400 focus:bg-white focus:ring-1 focus:ring-purple-400 text-xs font-bold text-gray-800 tracking-widest rounded outline-none transition-all placeholder:text-gray-400 placeholder:font-normal placeholder:tracking-normal uppercase" />
                                        <p className="text-[9px] text-gray-400">17 haneli VIN/şasi kodu</p>
                                    </div>
                                </div>
                            </div>

                            {/* Fiyat & Durum */}
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-3 pb-2 border-b border-gray-100">FİYAT & DURUM</p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                    <div className="flex flex-col gap-1 text-left">
                                        <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">
                                            Satış Fiyatı (₺) <span className="text-red-500">*</span>
                                        </label>
                                        <div className="relative">
                                            <input type="text" inputMode="numeric" placeholder="örn. 1.250.000"
                                                   value={form.price ? Number(form.price).toLocaleString("tr-TR") : ""}
                                                   onChange={e => setForm(f => ({ ...f, price: sanitizePrice(e.target.value) }))}
                                                   className="w-full px-3 py-2.5 pr-7 bg-gray-50 border border-gray-200 hover:border-gray-300 focus:border-purple-400 focus:bg-white focus:ring-1 focus:ring-purple-400 text-xs font-medium text-gray-700 rounded outline-none transition-all placeholder:text-gray-400" />
                                            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">₺</span>
                                        </div>
                                    </div>
                                    <SelectField label="Stok Durumu" required value={form.status} onChange={v => setForm(f => ({ ...f, status: v }))} options={STATUS_OPTIONS} />
                                </div>
                            </div>

                            {/* İlan Detayları */}
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-3 pb-2 border-b border-gray-100">İLAN DETAYLARI</p>
                                <div className="space-y-3">
                                    <div className="flex flex-col gap-1 text-left">
                                        <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">
                                            Başlık <span className="text-red-500">*</span>
                                        </label>
                                        <input type="text" placeholder="Otomatik oluşturulur veya kendiniz yazabilirsiniz"
                                               value={form.title}
                                               onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                                               className="px-3 py-2.5 bg-gray-50 border border-gray-200 hover:border-gray-300 focus:border-purple-400 focus:bg-white focus:ring-1 focus:ring-purple-400 text-xs font-medium text-gray-700 rounded outline-none transition-all placeholder:text-gray-400" />
                                    </div>
                                    <div className="flex flex-col gap-1 text-left">
                                        <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">Açıklama</label>
                                        <textarea rows={3} placeholder="Araç hakkında ek bilgiler..."
                                                  value={form.description}
                                                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                                                  className="px-3 py-2.5 bg-gray-50 border border-gray-200 hover:border-gray-300 focus:border-purple-400 focus:bg-white focus:ring-1 focus:ring-purple-400 text-xs font-medium text-gray-700 rounded outline-none transition-all resize-none placeholder:text-gray-400" />
                                    </div>
                                    <div className="flex flex-col gap-1 text-left">
                                        <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">
                                            Garanti & Taahhüt Cümlesi
                                            <span className="text-gray-400 font-normal normal-case ml-1">(düzenlenebilir)</span>
                                        </label>
                                        <textarea rows={2}
                                                  value={form.features.garanti_cumlesi ?? "Bu araç firmamızın garantisi altındadır; tüm bilgiler ekspertiz raporuna dayalı olup araç teslimde belirtilen özelliklere uygun olacaktır."}
                                                  onChange={e => setFeature("garanti_cumlesi", e.target.value)}
                                                  className="px-3 py-2.5 bg-purple-50/40 border border-purple-100 hover:border-purple-200 focus:border-purple-400 focus:bg-white text-xs font-medium text-gray-700 rounded outline-none transition-all resize-none" />
                                    </div>
                                </div>
                            </div>

                            {/* ARAÇ HASAR ŞEMASI */}
                            <VehicleDamageSchema
                                value={form.features.parca_durumlari || {}}
                                onChange={v => setFeature("parca_durumlari", v)}
                            />

                            {/* EKSPERTİZ & ARAÇ GEÇMİŞİ */}
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-3 pb-2 border-b border-gray-100">EKSPERTİZ & ARAÇ GEÇMİŞİ</p>
                                <div className="space-y-2.5">
                                    <label
                                        onClick={() => setFeature("eksper_raporu_mevcut", !form.features.eksper_raporu_mevcut)}
                                        className={`flex items-start gap-3 p-3 border rounded cursor-pointer transition-all select-none ${form.features.eksper_raporu_mevcut ? "bg-purple-50 border-purple-300" : "bg-white border-gray-200 hover:border-gray-300"}`}>
                                        <div className={`w-4 h-4 mt-0.5 flex-shrink-0 rounded border-2 flex items-center justify-center transition-all ${form.features.eksper_raporu_mevcut ? "bg-purple-600 border-purple-600" : "border-gray-300"}`}>
                                            {form.features.eksper_raporu_mevcut && <svg viewBox="0 0 10 8" className="w-2.5 h-2 text-white fill-current"><path d="M1 4l2.5 2.5L9 1" /></svg>}
                                        </div>
                                        <div>
                                            <p className={`text-xs font-bold ${form.features.eksper_raporu_mevcut ? "text-purple-800" : "text-gray-800"}`}>Eksper Raporu Mevcut</p>
                                            <p className={`text-[10px] mt-0.5 ${form.features.eksper_raporu_mevcut ? "text-purple-600" : "text-gray-400"}`}>Yetkili eksper tarafından hazırlanan rapor elinizde var</p>
                                        </div>
                                    </label>
                                    <label
                                        onClick={() => { setFeature("tramer_bilgisi_paylasiyorum", !form.features.tramer_bilgisi_paylasiyorum); if (form.features.tramer_bilgisi_paylasiyorum) setFeature("tramer_tutari", "") }}
                                        className={`flex items-start gap-3 p-3 border rounded cursor-pointer transition-all select-none ${form.features.tramer_bilgisi_paylasiyorum ? "bg-purple-50 border-purple-300" : "bg-white border-gray-200 hover:border-gray-300"}`}>
                                        <div className={`w-4 h-4 mt-0.5 flex-shrink-0 rounded border-2 flex items-center justify-center transition-all ${form.features.tramer_bilgisi_paylasiyorum ? "bg-purple-600 border-purple-600" : "border-gray-300"}`}>
                                            {form.features.tramer_bilgisi_paylasiyorum && <svg viewBox="0 0 10 8" className="w-2.5 h-2 text-white fill-current"><path d="M1 4l2.5 2.5L9 1" /></svg>}
                                        </div>
                                        <div>
                                            <p className={`text-xs font-bold ${form.features.tramer_bilgisi_paylasiyorum ? "text-purple-800" : "text-gray-800"}`}>Tramer Bilgisini Paylaşıyorum</p>
                                            <p className={`text-[10px] mt-0.5 ${form.features.tramer_bilgisi_paylasiyorum ? "text-purple-600" : "text-gray-400"}`}>Kaza geçmişi ve tramer kaydı şeffaf paylaşılsın</p>
                                        </div>
                                    </label>
                                    {form.features.tramer_bilgisi_paylasiyorum && (
                                        <div className="ml-7 flex flex-col gap-1">
                                            <label className="text-[9px] font-bold uppercase tracking-wider text-gray-500">Tramer Tutarı (₺)</label>
                                            <div className="relative">
                                                <input type="text" inputMode="numeric"
                                                       value={form.features.tramer_tutari ? Number(form.features.tramer_tutari).toLocaleString("tr-TR") : ""}
                                                       onChange={e => setFeature("tramer_tutari", sanitizePrice(e.target.value))}
                                                       placeholder="ör. 45.000"
                                                       className="w-full px-3 py-2.5 pr-8 bg-white border border-purple-200 focus:border-purple-400 text-xs font-medium text-gray-700 rounded outline-none transition-all placeholder:text-gray-400" />
                                                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">₺</span>
                                            </div>
                                        </div>
                                    )}
                                    <label
                                        onClick={() => setFeature("katilim_finansi_uyumlu", !form.features.katilim_finansi_uyumlu)}
                                        className={`flex items-start gap-3 p-3 border rounded cursor-pointer transition-all select-none ${form.features.katilim_finansi_uyumlu ? "bg-green-50 border-green-300" : "bg-white border-gray-200 hover:border-gray-300"}`}>
                                        <div className={`w-4 h-4 mt-0.5 flex-shrink-0 rounded border-2 flex items-center justify-center transition-all ${form.features.katilim_finansi_uyumlu ? "bg-green-600 border-green-600" : "border-gray-300"}`}>
                                            {form.features.katilim_finansi_uyumlu && <svg viewBox="0 0 10 8" className="w-2.5 h-2 text-white fill-current"><path d="M1 4l2.5 2.5L9 1" /></svg>}
                                        </div>
                                        <div>
                                            <p className={`text-xs font-bold ${form.features.katilim_finansi_uyumlu ? "text-green-800" : "text-gray-800"}`}>Katılım Finansı ile Satışa Uygun</p>
                                            <p className={`text-[10px] mt-0.5 ${form.features.katilim_finansi_uyumlu ? "text-green-600" : "text-gray-400"}`}>Faizsiz finansman kuruluşlarıyla çalışmaya uygunuz</p>
                                        </div>
                                    </label>
                                </div>
                            </div>

                            {/* Butonlar */}
                            <div className="flex gap-3 pt-4 border-t border-gray-100">
                                <Link to="/portfolio/vehicle"
                                      className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-gray-600 border border-gray-200 hover:bg-gray-50 rounded transition-colors">
                                    <ArrowLeft size={13} /> Geri
                                </Link>
                                <button type="submit" disabled={saving}
                                        className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-800 hover:to-indigo-700 disabled:opacity-50 text-white py-2.5 rounded text-xs font-bold uppercase tracking-wider transition-all shadow-sm">
                                    {saving ? <><Loader2 size={13} className="animate-spin" /> Kaydediliyor...</> : <><Save size={13} /> {isEdit ? "Güncelle" : "Portföye Ekle"}</>}
                                </button>
                            </div>
                        </form>
                    </div>

                    {/* Sağ: Bilgi + İpuçları */}
                    <div className="lg:col-span-4 flex flex-col gap-4">
                        <div className="bg-white border border-gray-200 rounded-sm shadow-sm overflow-hidden">
                            <div className="h-[3px] bg-purple-600" />
                            <div className="p-4">
                                <div className="flex items-center gap-3 mb-3">
                                    <div className="w-11 h-11 rounded bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-700 shadow-sm flex-shrink-0">
                                        <Car size={20} />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-gray-800">{isEdit ? "Aracı Düzenle" : "Yeni Araç"}</p>
                                        <p className="text-[11px] text-gray-500 font-medium mt-0.5">Vasıta Portföyü</p>
                                    </div>
                                </div>
                                <p className="text-[11px] text-gray-500 font-medium leading-relaxed">
                                    Marka, model ve donanım seçtiğinizde başlık otomatik oluşturulur; isterseniz kendiniz düzenleyebilirsiniz.
                                </p>
                                {form.title && (
                                    <div className="mt-4 pt-4 border-t border-gray-100">
                                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">İlan Başlığı</p>
                                        <p className="text-xs font-bold text-gray-800 leading-snug">{form.title}</p>
                                    </div>
                                )}
                                {form.price && (
                                    <div className="mt-3 flex items-center justify-between text-[11px]">
                                        <span className="text-gray-500 font-bold">Satış Fiyatı</span>
                                        <span className="font-bold text-gray-800">{Number(form.price).toLocaleString("tr-TR")} ₺</span>
                                    </div>
                                )}
                                <div className="mt-3 flex items-center justify-between text-[11px]">
                                    <span className="text-gray-500 font-bold">Stok Durumu</span>
                                    <span className="font-bold text-gray-800">{STATUS_OPTIONS.find(s => s.value === form.status)?.label || "—"}</span>
                                </div>

                                {isEdit && moderationStatus && (
                                    <div className="mt-3 flex items-center justify-between text-[11px]">
                                        <span className="text-gray-500 font-bold">Onay Durumu</span>
                                        <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                                            moderationStatus === "approved" ? "bg-green-50 text-green-700" :
                                                moderationStatus === "rejected" ? "bg-red-50 text-red-600" : "bg-amber-50 text-amber-700"
                                        }`} title={moderationStatus === "rejected" ? moderationNote : undefined}>
                      {moderationStatus === "approved" ? "Onaylandı" : moderationStatus === "rejected" ? "Reddedildi" : "İncelemede"}
                    </span>
                                    </div>
                                )}
                                {isEdit && moderationStatus === "rejected" && moderationNote && (
                                    <p className="mt-1.5 text-[10px] text-red-600 font-medium bg-red-50 border border-red-100 rounded px-2.5 py-1.5">
                                        Sebep: {moderationNote}
                                    </p>
                                )}

                                {isEdit && !ownershipVerifiedAt && (
                                    <div className="mt-3 flex items-center justify-between text-[11px] bg-amber-50 border border-amber-100 rounded px-2.5 py-2">
                    <span className="text-amber-700 font-bold text-[10px] leading-relaxed">
                      Sahiplik belgesi (ruhsat) yüklenip onaylanmadan bu araçla teklif verilemez.
                    </span>
                                    </div>
                                )}

                                {isEdit && (
                                    <div className="mt-4 pt-4 border-t border-gray-100">
                                        <div className="flex items-center justify-between mb-2">
                                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Araç Fotoğrafları ({images.length})</p>
                                            <button onClick={() => setShowGallery(true)}
                                                    className="flex items-center gap-1 text-[9px] font-bold text-purple-700 hover:text-purple-800 uppercase tracking-wider transition-colors">
                                                <ImagePlus size={11} /> Galeriyi Yönet
                                            </button>
                                        </div>
                                        {images.length > 0 ? (
                                            <div className="grid grid-cols-3 gap-2">
                                                {images.slice(0, 6).map((img, i) => (
                                                    <div key={img.id || i} onClick={() => setShowGallery(true)}
                                                         className="aspect-square rounded overflow-hidden border border-gray-200 hover:border-gray-300 bg-gray-50 cursor-pointer transition-all">
                                                        <img src={getImageUrl(img)} alt={`Araç fotoğrafı ${i + 1}`} className="w-full h-full object-cover" />
                                                    </div>
                                                ))}
                                            </div>
                                        ) : (
                                            <button onClick={() => setShowGallery(true)}
                                                    className="w-full flex flex-col items-center justify-center gap-1.5 border-2 border-dashed border-gray-200 hover:border-purple-300 hover:bg-purple-50/30 rounded py-5 transition-all">
                                                <Image size={18} className="text-gray-400" />
                                                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Fotoğraf Ekle</p>
                                            </button>
                                        )}
                                    </div>
                                )}

                                {isEdit && (
                                    <div className="mt-4 pt-4 border-t border-gray-100">
                                        <div className="flex items-center justify-between mb-2">
                                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Eksper Dökümanları ({documents.length})</p>
                                            <button onClick={() => setShowDocs(true)}
                                                    className="flex items-center gap-1 text-[9px] font-bold text-purple-700 hover:text-purple-800 uppercase tracking-wider transition-colors">
                                                <FileText size={11} /> Belgeleri Yönet
                                            </button>
                                        </div>
                                        {documents.length > 0 ? (
                                            <div className="flex flex-col gap-1.5">
                                                {documents.slice(0, 4).map(doc => (
                                                    <div key={doc.id} className="flex items-center gap-2 px-2.5 py-2 bg-gray-50 border border-gray-100 rounded">
                                                        <FileText size={12} className="text-gray-400 flex-shrink-0" />
                                                        <p className="text-[10px] font-bold text-gray-700 truncate">{doc.name || doc.file_name}</p>
                                                    </div>
                                                ))}
                                                {documents.length > 4 && (
                                                    <p className="text-[9px] text-gray-400 font-bold text-center">+{documents.length - 4} belge daha</p>
                                                )}
                                            </div>
                                        ) : (
                                            <button onClick={() => setShowDocs(true)}
                                                    className="w-full flex flex-col items-center justify-center gap-1.5 border-2 border-dashed border-gray-200 hover:border-purple-300 hover:bg-purple-50/30 rounded py-5 transition-all">
                                                <FileText size={18} className="text-gray-400" />
                                                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Belge Ekle</p>
                                            </button>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="bg-gray-900 border border-gray-800 rounded-sm shadow-sm p-4 text-white">
                            <p className="text-[9px] font-bold uppercase tracking-wider text-purple-400 mb-1.5">İpucu</p>
                            <h3 className="font-bold text-sm text-white leading-snug mb-1">Eksiksiz bilgi, hızlı eşleşme</h3>
                            <p className="text-gray-400 text-[10px] font-medium leading-relaxed">
                                Yakıt, vites, renk ve plaka ili gibi detayları doldurmak; aracınızın gelen taleplerle otomatik eşleşme şansını artırır.
                            </p>
                        </div>
                    </div>
                </div>
            </main>

            {showGallery && (
                <ImageUploadModal
                    item={{ id, title: form.title, images }}
                    onClose={() => setShowGallery(false)}
                    onUpdate={setImages}
                />
            )}
            {showDocs && (
                <DocumentUploadModal
                    item={{ id, title: form.title }}
                    initialDocuments={documents}
                    onClose={() => setShowDocs(false)}
                    onUpdate={setDocuments}
                />
            )}
        </div>
    )
}